#' 'AHAprevent' Package: AHA PREVENT equations for R
#'
#'  The 'AHAprevent' package implements the American Heart Association's
#'  Predicting Risk of Cardiovascular Disease EVENTs ("PREVENT") equations.
#'  The PREVENT equations predict 10-year and 30-year risk for total CVD,
#'  ASCVD, and HF. These equations reflect the interplay between the cardiovascular
#'  system, chronic kidney disease, and metabolic health
#'  (Khan et al., 2024; Khan et al., 2023).
#'
#' This package includes five functions that each output 10-year and 30-year risks
#' for total CVD, ASCVD, and HF (absolute risks, percent):
#'  \itemize{
#'    \item \code{\link{prevent_base}}: Base equation
#'    \item \code{\link{prevent_uacr}}: Base + UACR equation
#'    \item \code{\link{prevent_hba1c}}: Base + HbA1c equation
#'    \item \code{\link{prevent_sdi}}: Base + SDI equation
#'    \item \code{\link{prevent_full}}: Full equation (Base + UACR + HbA1c + SDI)
#'  }
#'
#'  Please see the AHA-DS-Analytics GitHub (\url{https://github.com/AHA-DS-Analytics/PREVENT/blob/main/R/AHAprevent_Package_Help.md}) for full documentation on how to use this R package.
#'
#' @references
#' Inker, L. A., Eneanya, N. D., Coresh, J., Tighiouart, H., Wang, D.,
#' Sang, Y., Crews, D. C., Doria, A., Estrella, M. M., Froissart, M.,
#' Grams, M. E., Greene, T., Grubb, A., Gudnason, V., Gutiérrez, O. M.,
#' Kalil, R., Karger, A. B., Mauer, M., Navis, G., Nelson, R. G., Poggio,
#' E. D., Rodby, R., Rossing, P., Rule, A. D., Selvin, E., Seegmiller, J. C.,
#' Shlipak, M. G., Torres, V. E., Yang, W., Ballew, S. H., Couture, S. J.,
#' Powe, N. R., & Levey, A. S., for the Chronic Kidney Disease Epidemiology
#' Collaboration (2021).New Creatinine- and Cystatin C-Based Equations to
#' Estimate GFR without Race. The New England journal of medicine, 385(19), 1737–1749.
#' \url{https://doi.org/10.1056/NEJMoa2102953}
#'
#' Khan, S. S., Coresh, J., Pencina, M. J., Ndumele, C. E., Rangaswami, J.,
#' Chow, S. L., Palaniappan, L. P., Sperling, L. S., Virani, S. S., Ho, J. E.,
#' Neeland, I. J., Tuttle, K. R., Rajgopal Singh, R., Elkind, M. S. V.,
#' Lloyd-Jones, D. M., & American Heart Association (2023). Novel Prediction
#' Equations for Absolute Risk Assessment of Total Cardiovascular Disease
#' Incorporating Cardiovascular-Kidney-Metabolic Health: A Scientific Statement
#' From the American Heart Association. Circulation, 148(24), 1982–2004.
#' \url{https://doi.org/10.1161/CIR.0000000000001191}
#'
#' Khan, S. S., Matsushita, K., Sang, Y., Ballew, S. H., Grams, M. E.,
#' Surapaneni, A., Blaha, M. J., Carson, A. P., Chang, A. R., Ciemins, E., Go, A.
#' S., Gutierrez, O. M., Hwang, S. J., Jassal, S. K., Kovesdy, C. P., Lloyd-Jones,
#' D. M., Shlipak, M. G., Palaniappan, L. P., Sperling, L., Virani, S. S., Tuttle, K.,
#' Neeland, I. J., Chow, S. L., Rangaswami, J., Pencina, M. J., Ndumele, C. E., &
#' Coresh, J., for the Chronic Kidney Disease Prognosis Consortium and the American Heart Association
#' Cardiovascular-Kidney-Metabolic Science Advisory Group (2024). Development and
#' Validation of the American Heart Association Predicting Risk of Cardiovascular
#' Disease EVENTs (PREVENT) Equations. Circulation, 149(6), 430–449.
#' \url{https://doi.org/10.1161/CIRCULATIONAHA.123.067626}
#'
#' Social deprivation index (SDI). (2018, November 5). Robert Graham Center -
#' Policy Studies in Family Medicine & Primary Care.
#' \url{https://www.graham-center.org/rgc/maps-data-tools/sdi/social-deprivation-index.html}
#'
#' @author Vaishnavi Krishnan\eqn{^1}, Lucia C. Petito\eqn{^2}, Xiaoning Huang\eqn{^1}, and Sadiya S. Khan\eqn{^{1,2}}
#'
#' \eqn{^1}\emph{Department of Medicine, Division of Cardiovascular Medicine, Northwestern University Feinberg School of Medicine}
#'
#' \eqn{^2}\emph{Department of Preventive Medicine, Northwestern University Feinberg School of Medicine}
#'
#'
#' @docType _PACKAGE
#'
#' @name AHAprevent
#'
#'
NULL
