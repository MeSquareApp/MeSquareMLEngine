#' @description
#'
#' 'sdicat' converts input variables to the required units within the
#' 'AHAprevent' functions
#'
#' @name sdicat
#' @title SDI conversion function required for the 'AHAprevent' package
#' @param SDI Social Deprivation Index (SDI) decile (integer 1-10), numeric.
#' @return Social Deprivation Index (SDI) tertile (0, 1, 2), numeric.
#' @keywords internal

sdicat <- function(SDI) {
  if (!is.na(SDI)) {
    if (SDI > 0 & SDI < 4) {
      return(0)
    } else if (SDI >= 4 & SDI < 7) {
      return(1)
    } else if (SDI >= 7 & SDI <= 10){
      return(2)
    }
  }
}

#' @description
#'
#' 'mmol_conversion' converts input variables to the required units within the
#' 'AHAprevent' functions
#'
#' @name mmol_conversion
#' @title Cholesterol conversion function required for the 'AHAprevent' package
#' @param cholesterol Cholesterol in mg/dL, numeric.
#' @return Cholesterol in mmol/L, numeric.
#' @keywords internal

mmol_conversion <- function(cholesterol) {m = 0.02586*cholesterol
return(m)}

#' @description
#'
#' 'adjust' rounds any 0 <= UACR < 0.1 to 0.1 within the 'AHAprevent' functions
#'
#' @name adjust
#' @title Adjust function required for the 'AHAprevent' package
#' @param UACR Urine albumin-creatinine ratio (>=0 mg/g), numeric.
#' @return Urine albumin-creatinine ratio (>=0 mg/g), numeric.
#' @keywords internal

adjust <- function(UACR) {
  if (!is.na(UACR)) {
    if (UACR >= 0.1) {
      return(UACR)
    } else if (0 <= UACR & UACR < 0.1) {
      return(0.1)
    }
  }
}

#' @name pred_risk_base
#' @title pred_risk_base
#' @param sex Sex, numeric.
#' \itemize{
#'     \item 0 = male
#'     \item 1 = female
#'  }
#' @param age Age (30-79 yrs), numeric.
#' @param tc Total cholesterol (130-320 mg/dL), numeric.
#'
#' \emph{Used in the calculation of non-HDL cholesterol for input into equations, where non-HDL = TC - HDL}.
#' @param hdl High density lipoprotein cholesterol (20-100 mg/dL), numeric.
#' @param sbp Systolic blood pressure (90-200 mmHg), numeric.
#' @param dm Diabetes status (0 or 1), numeric.
#' \itemize{
#'     \item 0 = no history of diabetes
#'     \item 1 = any history of diabetes
#' }
#' @param smoking Smoking status (0 or 1), numeric.
#' \itemize{
#'    \item 0 = non-smoking individual
#'    \item 1 = current smoking
#' }
#' @param bmi Body mass index (18.5-39.9 kg/m^2), numeric.
#' @param egfr Estimated glomerular filtration rate (>0 mL/min/1.73m^2), numeric.
#'
#' \emph{Calculated using the 2021 CKD-EPI creatinine equation (Inker et al., 2021)}.
#' @param bptreat Treatment for hypertension (0 or 1), numeric.
#' \itemize{
#'    \item 0 = no treatment
#'    \item 1 = any treatment
#' }
#' @param statin Statin use (0 or 1), numeric.
#' \itemize{
#'    \item 0 = no statin use
#'    \item 1 = any statin use
#' }
#' @keywords internal

pred_risk_base <- function(sex, age, tc, hdl, sbp, dm, smoking, bmi, egfr, bptreat, statin) {

  if(!all(is.numeric(sex) & (sex %in% c(0, 1)))) {
    prevent_base_30yr_ASCVD = prevent_base_30yr_HF = prevent_base_30yr_CVD = prevent_base_10yr_ASCVD = prevent_base_10yr_HF = prevent_base_10yr_CVD = NA
  } else {
    if(sex==1) {
      logor_10yr_CVD = -3.307728 +
        0.7939329*(age - 55)/10 +
        0.0305239*(mmol_conversion(tc - hdl) - 3.5) -
        0.1606857*(mmol_conversion(hdl) - 1.3)/(0.3) -
        0.2394003*(min(sbp, 110) - 110)/20 +
        0.360078*(max(sbp, 110) - 130)/20 +
        0.8667604*(dm) +
        0.5360739*(smoking) +
        0.6045917*(min(egfr, 60) - 60)/(-15) +
        0.0433769*(max(egfr, 60) - 90)/(-15) +
        0.3151672*(bptreat) -
        0.1477655*(statin) -
        0.0663612*(bptreat)*(max(sbp, 110) - 130)/20 +
        0.1197879*(statin)*(mmol_conversion(tc - hdl) - 3.5) -
        0.0819715*(age - 55)/10*(mmol_conversion(tc - hdl) - 3.5) +
        0.0306769*(age - 55)/10*(mmol_conversion(hdl) - 1.3)/(0.3) -
        0.0946348*(age - 55)/10*(max(sbp, 110) - 130)/20 -
        0.27057*(age - 55)/10*(dm) -
        0.078715*(age - 55)/10*(smoking) -
        0.1637806*(age - 55)/10*(min(egfr, 60) - 60)/(-15)

      logor_30yr_CVD = -1.318827 +
        0.5503079*(age - 55)/10 -
        0.0928369*(((age - 55)/10)^2) +
        0.0409794*(mmol_conversion(tc - hdl) - 3.5) +
        (-0.1663306)*(mmol_conversion(hdl) - 1.3)/(0.3) +
        (-0.1628654)*(min(sbp, 110) - 110)/20 +
        0.3299505*(max(sbp, 110) - 130)/20 +
        0.6793894*(dm) +
        0.3196112*(smoking) +
        0.1857101*(min(egfr, 60) - 60)/(-15) +
        0.0553528*(max(egfr, 60) - 90)/(-15) +
        0.2894*(bptreat) +
        (-0.075688)*(statin) +
        (-0.056367)*(bptreat)*(max(sbp, 110) - 130)/20 +
        (0.1071019)*(statin)*(mmol_conversion(tc - hdl) - 3.5) +
        (-0.0751438)*(age - 55)/10*(mmol_conversion(tc - hdl) - 3.5) +
        (0.0301786)*(age - 55)/10*(mmol_conversion(hdl) - 1.3)/(0.3) +
        (-0.0998776)*(age - 55)/10*(max(sbp, 110) - 130)/20 +
        (-0.3206166)*(age - 55)/10*(dm) +
        (-0.1607862)*(age - 55)/10*(smoking) +
        (-0.1450788)*(age - 55)/10*(min(egfr, 60) - 60)/(-15)

      logor_10yr_ASCVD = -3.819975 +
        0.719883*(age - 55)/10 +
        0.1176967*((mmol_conversion(tc) - mmol_conversion(hdl)) - 3.5) -
        0.151185*(mmol_conversion(hdl) - 1.3)/0.3 - 0.0835358*(min(sbp, 110) - 110)/20 +
        0.3592852*(max(sbp, 110) - 130)/20 +
        0.8348585*(dm) + 0.4831078*(smoking) +
        0.4864619*(min(egfr, 60) - 60)/(-15) +
        0.0397779*(max(egfr, 60)  - 90)/(-15) +
        0.2265309*(bptreat) -
        0.0592374*(statin) -
        0.0395762*(bptreat)*(max(sbp, 110) - 130)/20  +
        0.0844423*(statin)*((mmol_conversion(tc) - mmol_conversion(hdl)) - 3.5) -
        0.0567839*(age - 55)/10*((mmol_conversion(tc) - mmol_conversion(hdl)) - 3.5) +
        0.0325692*(age - 55)/10*(mmol_conversion(hdl) - 1.3)/0.3 -
        0.1035985*(age - 55)/10*(max(sbp, 110) - 130)/20 -
        0.2417542*(age - 55)/10*(dm) -
        0.0791142*(age - 55)/10*(smoking) -
        0.1671492*(age - 55)/10*(min(egfr, 60) - 60)/(-15)

      logor_30yr_ASCVD = -1.974074 +
        0.4669202*((age - 55)/10) -
        0.0893118*((age - 55)/10) ^ 2 +
        0.1256901*((mmol_conversion(tc) - mmol_conversion(hdl))- 3.5) -
        0.1542255*(mmol_conversion(hdl)- 1.3)/0.3 -
        0.0018093*(min(sbp, 110) - 110)/20 +
        0.322949*(max(sbp, 110) - 130)/20 +
        0.6296707*(dm) +
        0.268292*(smoking) +
        0.100106*(min(egfr, 60) - 60)/(-15) +
        0.0499663*(max(egfr, 60) - 90)/(-15) +
        0.1875292*(bptreat) +
        0.0152476*(statin) -
        0.0276123*(bptreat)*(max(sbp, 110) - 130)/20 +
        0.0736147*(statin)*((mmol_conversion(tc) - mmol_conversion(hdl))- 3.5) -
        0.0521962*(age - 55)/10*((mmol_conversion(tc) - mmol_conversion(hdl))- 3.5) +
        0.0316918*(age - 55)/10*(mmol_conversion(hdl)- 1.3)/0.3 -
        0.1046101*(age - 55)/10*(max(sbp, 110) - 130)/20 -
        0.2727793*(age - 55)/10*(dm) -
        0.1530907*(age - 55)/10*(smoking) -
        0.1299149*(age - 55)/10*(min(egfr, 60) - 60)/(-15)

      logor_10yr_HF = -4.310409 +
        0.8998235*(age - 55)/10 -
        0.4559771*(min(sbp, 110) - 110)/20 +
        0.3576505*(max(sbp, 110) - 130)/20 +
        1.038346*(dm) +
        0.583916*(smoking) -
        0.0072294*(min(bmi, 30) - 25)/5 +
        0.2997706*(max(bmi, 30) - 30)/5 +
        0.7451638*(min(egfr, 60) - 60)/(-15) +
        0.0557087*(max(egfr, 60)  - 90)/(-15) +
        0.3534442*(bptreat) -
        0.0981511*(bptreat)*(max(sbp, 110) - 130)/20  -
        0.0946663*(age - 55)/10*(max(sbp, 110) - 130)/20 -
        0.3581041*(age - 55)/10*(dm) -
        0.1159453*(age - 55)/10*(smoking) -
        0.003878*(age - 55)/10*(max(bmi, 30) - 30)/5 -
        0.1884289*(age - 55)/10*(min(egfr, 60) - 60)/(-15)

      logor_30yr_HF = -2.205379 +
        0.6254374*((age - 55)/10) -
        0.0983038*((age - 55)/10) ^ 2 -
        0.3919241*(min(sbp, 110) - 110)/20 +
        0.3142295*(max(sbp, 110) - 130)/20 +
        0.8330787*(dm) +
        0.3438651*(smoking) +
        0.0594874*(min(bmi, 30) - 25)/5 +
        0.2525536*(max(bmi, 30) - 30)/5 +
        0.2981642*(min(egfr, 60) - 60)/(-15) +
        0.0667159*(max(egfr, 60) - 90)/(-15) +
        0.333921*(bptreat) -
        0.0893177*(bptreat)*(max(sbp, 110) - 130)/20 -
        0.0974299*(age - 55)/10*(max(sbp, 110) - 130)/20 -
        0.404855*(age - 55)/10*(dm) -
        0.1982991*(age - 55)/10*(smoking) -
        0.0035619*(age - 55)/10*(max(bmi, 30) - 30)/5 -
        0.1564215*(age - 55)/10*(min(egfr, 60) - 60)/(-15)
    }
    else {
      logor_10yr_CVD = -3.031168 +
        0.7688528*(age - 55)/10 +
        0.0736174*(mmol_conversion(tc - hdl) - 3.5) -
        0.0954431*(mmol_conversion(hdl) - 1.3)/(0.3) -
        0.4347345*(min(sbp, 110) - 110)/20 +
        0.3362658*(max(sbp, 110) - 130)/20 +
        0.7692857*(dm) +
        0.4386871*(smoking) +
        0.5378979*(min(egfr, 60) - 60)/(-15) +
        0.0164827*(max(egfr, 60) - 90)/(-15) +
        0.288879*(bptreat) -
        0.1337349*(statin) -
        0.0475924*(bptreat)*(max(sbp, 110) - 130)/20 +
        0.150273*(statin)*(mmol_conversion(tc - hdl) - 3.5) -
        0.0517874*(age - 55)/10*(mmol_conversion(tc - hdl) - 3.5) +
        0.0191169*(age - 55)/10*(mmol_conversion(hdl) - 1.3)/(0.3) -
        0.1049477*(age - 55)/10*(max(sbp, 110) - 130)/20 -
        0.2251948*(age - 55)/10*(dm) -
        0.0895067*(age - 55)/10*(smoking) -
        0.1543702*(age - 55)/10*(min(egfr, 60) - 60)/(-15)

      logor_30yr_CVD = -1.148204 +
        0.4627309*(age - 55)/10 -
        0.0984281*(((age - 55)/10)^2) +
        0.0836088*(mmol_conversion(tc - hdl) - 3.5) +
        (-0.1029824)*(mmol_conversion(hdl) - 1.3)/(0.3) +
        (-0.2140352)*(min(sbp, 110) - 110)/20 +
        0.2904325*(max(sbp, 110) - 130)/20 +
        0.5331276*(dm) +
        0.2141914*(smoking) +
        0.1155556*(min(egfr, 60) - 60)/(-15) +
        0.0603775*(max(egfr, 60) - 90)/(-15) +
        0.232714*(bptreat) +
        (-0.0272112)*(statin) +
        (-0.0384488)*(bptreat)*(max(sbp, 110) - 130)/20 +
        (0.134192)*(statin)*(mmol_conversion(tc - hdl) - 3.5) +
        (-0.0511759)*(age - 55)/10*(mmol_conversion(tc - hdl) - 3.5) +
        0.0165865*(age - 55)/10*(mmol_conversion(hdl) - 1.3)/(0.3) +
        (-0.1101437)*(age - 55)/10*(max(sbp, 110) - 130)/20 +
        (-0.2585943)*(age - 55)/10*(dm) +
        (-0.1566406)*(age - 55)/10*(smoking) +
        (-0.1166776)*(age - 55)/10*(min(egfr, 60) - 60)/(-15)

      logor_10yr_ASCVD = -3.500655 +
        0.7099847*(age - 55)/10 +
        0.1658663*((mmol_conversion(tc) - mmol_conversion(hdl)) - 3.5) -
        0.1144285*(mmol_conversion(hdl) - 1.3)/0.3 - 0.2837212*(min(sbp, 110) - 110)/20 +
        0.3239977*(max(sbp, 110) - 130)/20 +
        0.7189597*(dm) +
        0.3956973*(smoking) +
        0.3690075*(min(egfr, 60) - 60)/(-15) +
        0.0203619*(max(egfr, 60)  - 90)/(-15) +
        0.2036522*(bptreat) -
        0.0865581*(statin) -
        0.0322916*(bptreat)*(max(sbp, 110) - 130)/20 +
        0.114563*(statin)*((mmol_conversion(tc) - mmol_conversion(hdl)) - 3.5) -
        0.0300005*(age - 55)/10*((mmol_conversion(tc) - mmol_conversion(hdl)) - 3.5) +
        0.0232747*(age - 55)/10*(mmol_conversion(hdl) - 1.3)/0.3 -
        0.0927024*(age - 55)/10*(max(sbp, 110) - 130)/20 -
        0.2018525*(age - 55)/10*(dm) -
        0.0970527*(age - 55)/10*(smoking) -
        0.1217081*(age - 55)/10*(min(egfr, 60) - 60)/(-15)

      logor_30yr_ASCVD = -1.736444 +
        0.3994099*((age - 55)/10) -
        0.0937484*((age - 55)/10) ^ 2 +
        0.1744643*((mmol_conversion(tc) - mmol_conversion(hdl))- 3.5) -
        0.120203*(mmol_conversion(hdl)- 1.3)/0.3 -
        0.0665117*(min(sbp, 110) - 110)/20 +
        0.2753037*(max(sbp, 110) - 130)/20 +
        0.4790257*(dm) +
        0.1782635*(smoking) -
        0.0218789*(min(egfr, 60) - 60)/(-15) +
        0.0602553*(max(egfr, 60) - 90)/(-15) +
        0.1421182*(bptreat) +
        0.0135996*(statin) -
        0.0218265*(bptreat)*(max(sbp, 110) - 130)/20 +
        0.1013148*(statin)*((mmol_conversion(tc) - mmol_conversion(hdl))- 3.5) -
        0.0312619*(age - 55)/10*((mmol_conversion(tc) - mmol_conversion(hdl))- 3.5) +
        0.020673*(age - 55)/10*(mmol_conversion(hdl)- 1.3)/0.3 -
        0.0920935*(age - 55)/10*(max(sbp, 110) - 130)/20 -
        0.2159947*(age - 55)/10*(dm) -
        0.1548811*(age - 55)/10*(smoking) -
        0.0712547*(age - 55)/10*(min(egfr, 60) - 60)/(-15)

      logor_10yr_HF = -3.946391 +
        0.8972642*(age - 55)/10 -
        0.6811466*(min(sbp, 110) - 110)/20 +
        0.3634461*(max(sbp, 110) - 130)/20 +
        0.923776*(dm) +
        0.5023736*(smoking) -
        0.0485841*(min(bmi, 30) - 25)/5 +
        0.3726929*(max(bmi, 30) - 30)/5 +
        0.6926917*(min(egfr, 60) - 60)/(-15) +
        0.0251827*(max(egfr, 60)  - 90)/(-15) +
        0.2980922*(bptreat) -
        0.0497731*(bptreat)*(max(sbp, 110) - 130)/20 -
        0.1289201*(age - 55)/10*(max(sbp, 110) - 130)/20 -
        0.3040924*(age - 55)/10*(dm) -
        0.1401688*(age - 55)/10*(smoking) +
        0.0068126*(age - 55)/10*(max(bmi, 30) - 30)/5 -
        0.1797778*(age - 55)/10*(min(egfr, 60) - 60)/(-15)

      logor_30yr_HF = -1.95751 +
        0.5681541*((age - 55)/10) -
        0.1048388*((age - 55)/10) ^ 2 -
        0.4761564*(min(sbp, 110) - 110)/20 +
        0.30324*(max(sbp, 110) - 130)/20 +
        0.6840338*(dm) +
        0.2656273*(smoking) +
        0.0833107*(min(bmi, 30) - 25)/5 +
        0.26999*(max(bmi, 30) - 30)/5 +
        0.2541805*(min(egfr, 60) - 60)/(-15) +
        0.0638923*(max(egfr, 60) - 90)/(-15) +
        0.2583631*(bptreat) -
        0.0391938*(bptreat)*(max(sbp, 110) - 130)/20 -
        0.1269124*(age - 55)/10*(max(sbp, 110) - 130)/20 -
        0.3273572*(age - 55)/10*(dm) -
        0.2043019*(age - 55)/10*(smoking) -
        0.0182831*(age - 55)/10*(max(bmi, 30) - 30)/5 -
        0.1342618*(age - 55)/10*(min(egfr, 60) - 60)/(-15)
    }
    prevent_base_10yr_CVD = 100*exp(logor_10yr_CVD) / (1 + exp(logor_10yr_CVD))
    prevent_base_30yr_CVD = 100*exp(logor_30yr_CVD) / (1 + exp(logor_30yr_CVD))
    prevent_base_10yr_ASCVD = 100*exp(logor_10yr_ASCVD) / (1 + exp(logor_10yr_ASCVD))
    prevent_base_30yr_ASCVD = 100*exp(logor_30yr_ASCVD) / (1 + exp(logor_30yr_ASCVD))
    prevent_base_10yr_HF = 100*exp(logor_10yr_HF) / (1 + exp(logor_10yr_HF))
    prevent_base_30yr_HF = 100*exp(logor_30yr_HF) / (1 + exp(logor_30yr_HF))

  }

  if (!is.na(age)) {
    if(age > 59 & age <= 79) {
      prevent_base_30yr_ASCVD = prevent_base_30yr_HF = prevent_base_30yr_CVD = NA
    } else if (age < 30 | age > 79){
      prevent_base_30yr_ASCVD = prevent_base_30yr_HF = prevent_base_30yr_CVD = prevent_base_10yr_ASCVD = prevent_base_10yr_HF = prevent_base_10yr_CVD = NA
    }
  }

  if (is.na(tc) | tc < 130 | tc > 320) { prevent_base_30yr_ASCVD = prevent_base_30yr_CVD = prevent_base_10yr_ASCVD = prevent_base_10yr_CVD = NA
  }

  if (is.na(hdl) | hdl < 20 | hdl > 100) { prevent_base_30yr_ASCVD = prevent_base_30yr_CVD = prevent_base_10yr_ASCVD = prevent_base_10yr_CVD = NA
  }

  if (is.na(sbp) | sbp < 90 | sbp > 200) { prevent_base_30yr_ASCVD = prevent_base_30yr_HF = prevent_base_30yr_CVD = prevent_base_10yr_ASCVD = prevent_base_10yr_HF = prevent_base_10yr_CVD = NA
  }

  if(!(all(is.numeric(dm)) & (dm %in% c(0, 1)))) { prevent_base_30yr_ASCVD = prevent_base_30yr_HF = prevent_base_30yr_CVD = prevent_base_10yr_ASCVD = prevent_base_10yr_HF = prevent_base_10yr_CVD = NA
  }

  if(!(all(is.numeric(smoking)) & (smoking %in% c(0, 1)))) { prevent_base_30yr_ASCVD = prevent_base_30yr_HF = prevent_base_30yr_CVD = prevent_base_10yr_ASCVD = prevent_base_10yr_HF = prevent_base_10yr_CVD = NA
  }

  if (is.na(egfr) | egfr <= 0) { prevent_base_30yr_ASCVD = prevent_base_30yr_HF = prevent_base_30yr_CVD = prevent_base_10yr_ASCVD = prevent_base_10yr_HF = prevent_base_10yr_CVD = NA
  }

  if(!(all(is.numeric(bptreat)) & (bptreat %in% c(0, 1)))) { prevent_base_30yr_ASCVD = prevent_base_30yr_HF = prevent_base_30yr_CVD = prevent_base_10yr_ASCVD = prevent_base_10yr_HF = prevent_base_10yr_CVD = NA
  }

  if(!(all(is.numeric(statin)) & (statin %in% c(0, 1)))) { prevent_base_30yr_ASCVD = prevent_base_30yr_CVD = prevent_base_10yr_ASCVD = prevent_base_10yr_CVD = NA
  }

  if (is.na(bmi) | bmi < 18.5 | bmi >= 40) { prevent_base_30yr_HF = prevent_base_10yr_HF = NA
  }

  prevent_base_values <- data.frame(prevent_base_10yr_CVD = prevent_base_10yr_CVD,
                                    prevent_base_10yr_ASCVD = prevent_base_10yr_ASCVD,
                                    prevent_base_10yr_HF = prevent_base_10yr_HF,
                                    prevent_base_30yr_CVD = prevent_base_30yr_CVD,
                                    prevent_base_30yr_ASCVD = prevent_base_30yr_ASCVD,
                                    prevent_base_30yr_HF = prevent_base_30yr_HF)

  return(prevent_base_values)
}

#' @name pred_risk_base_v
#' @title pred_risk_base_v
#' @param sex Sex, numeric.
#' \itemize{
#'     \item 0 = male
#'     \item 1 = female
#'  }
#' @param age Age (30-79 yrs), numeric.
#' @param tc Total cholesterol (130-320 mg/dL), numeric.
#'
#' \emph{Used in the calculation of non-HDL cholesterol for input into equations, where non-HDL = TC - HDL}.
#' @param hdl High density lipoprotein cholesterol (20-100 mg/dL), numeric.
#' @param sbp Systolic blood pressure (90-200 mmHg), numeric.
#' @param dm Diabetes status (0 or 1), numeric.
#' \itemize{
#'     \item 0 = no history of diabetes
#'     \item 1 = any history of diabetes
#' }
#' @param smoking Smoking status (0 or 1), numeric.
#' \itemize{
#'    \item 0 = non-smoking individual
#'    \item 1 = current smoking
#' }
#' @param bmi Body mass index (18.5-39.9 kg/m^2), numeric.
#' @param egfr Estimated glomerular filtration rate (>0 mL/min/1.73m^2), numeric.
#'
#' \emph{Calculated using the 2021 CKD-EPI creatinine equation (Inker et al., 2021)}.
#' @param bptreat Treatment for hypertension (0 or 1), numeric.
#' \itemize{
#'    \item 0 = no treatment
#'    \item 1 = any treatment
#' }
#' @param statin Statin use (0 or 1), numeric.
#' \itemize{
#'    \item 0 = no statin use
#'    \item 1 = any statin use
#' }
#' @keywords internal


pred_risk_base_v <- Vectorize(pred_risk_base)


#' @description \strong{prevent_base} returns the predicted risks (absolute risk, percent)
#' using the PREVENT base equation. \cr
#' @details Individuals missing any required input variables (sex, age, sbp, dm, smoking, egfr, bptreat)
#' will return "NA" since these are required variables to calculate risk estimates. Cholesterol variables (tc, hdl, statin)
#' are required for total CVD and ASCVD risk calculations while bmi is required for HF risk
#' calculation; individuals missing these variables will return "NA" only for the calculation of risks
#' requiring the input. If risk factor levels are out of range based on how this was defined in the development of the
#' equations (Khan et al., 2024), a risk estimate will not be calculated and the function will return “NA”.
#'
#' @name prevent_base
#' @title AHA PREVENT base equation
#' @param sex Sex, numeric.
#' \itemize{
#'     \item 0 = male
#'     \item 1 = female
#'  }
#' @param age Age (30-79 yrs), numeric.
#' @param tc Total cholesterol (130-320 mg/dL), numeric.
#'
#' \emph{Used in the calculation of non-HDL cholesterol for input into equations, where non-HDL = TC - HDL}.
#' @param hdl High density lipoprotein cholesterol (20-100 mg/dL), numeric.
#' @param sbp Systolic blood pressure (90-200 mmHg), numeric.
#' @param dm Diabetes status (0 or 1), numeric.
#' \itemize{
#'     \item 0 = no history of diabetes
#'     \item 1 = any history of diabetes
#' }
#' @param smoking Smoking status (0 or 1), numeric.
#' \itemize{
#'    \item 0 = non-smoking individual
#'    \item 1 = current smoking
#' }
#' @param bmi Body mass index (18.5-39.9 kg/m^2), numeric.
#' @param egfr Estimated glomerular filtration rate (>0 mL/min/1.73m^2), numeric.
#'
#' \emph{Calculated using the 2021 CKD-EPI creatinine equation (Inker et al., 2021)}.
#' @param bptreat Treatment for hypertension (0 or 1), numeric.
#' \itemize{
#'    \item 0 = no treatment
#'    \item 1 = any treatment
#' }
#' @param statin Statin use (0 or 1), numeric.
#' \itemize{
#'    \item 0 = no statin use
#'    \item 1 = any statin use
#' }
#'
#' @returns Data frame containing six variables: prevent_base_10yr_CVD,
#' prevent_base_30yr_CVD, prevent_base_10yr_ASCVD,
#' prevent_base_30yr_ASCVD, prevent_base_10yr_HF, and prevent_base_30yr_HF.
#' \itemize{
#'    \item prevent_base_10yr_CVD = Predicted 10-year Total CVD risk
#'    \item prevent_base_30yr_CVD = Predicted 30-year Total CVD risk
#'    \item prevent_base_10yr_ASCVD = Predicted 10-year ASCVD risk
#'    \item prevent_base_30yr_ASCVD = Predicted 30-year ASCVD risk
#'    \item prevent_base_10yr_HF = Predicted 10-year HF risk
#'    \item prevent_base_30yr_HF = Predicted 30-year HF risk
#' }
#'
#' @export
#'
#' @examples
#' ## Calculate predicted risks for a 45-year-old woman with a TC of 200 mg/dL
#' ## and HDL-C of 60 mg/dL (not on statin therapy), a systolic blood pressure of
#' ## 120 mm Hg (not on anti-hypertensive treatment), has diabetes, does not smoke,
#' ## with a BMI of 25 kg/m^2 and eGFR of 95 mL/min/1.73m^2.
#' \donttest{
#'   prevent_base(sex = 1, age = 45, tc = 200, hdl = 60, sbp = 120, dm = 1,
#'   smoking = 0, bmi = 25, egfr = 95, bptreat = 0, statin = 0)
#' }
#' ## Calculate predicted 10-year risks only for 75-year old man
#' ## (no 30-year risks calculated due to age > 75).
#' \donttest{
#'   prevent_base(sex = 0, age = 75, tc = 250, hdl = 90, sbp = 130, dm = 0,
#'   smoking = 1, bmi = 30, egfr = 105, bptreat = 1, statin = 1)
#' }
#' ## Calculate predicted total CVD and ASCVD risks only for 39-year old woman
#' ## (no HF risks calculated due to missing BMI).
#' \donttest{
#'   prevent_base(sex = 1, age = 39, tc = 190, hdl = 50, sbp = 110, dm = 0,
#'   smoking = 0, bmi = NA, egfr = 120, bptreat = 0, statin = 0)
#' }
#' ## Calculate predicted HF risks only for 58-year old man
#' ## (no CVD/ASCVD risks calculated due to missing cholesterol/statin variables).
#' \donttest{
#'   prevent_base(sex = 0, age = 58, tc = 230, hdl = NA, sbp = 150, dm = 0,
#'   smoking = 0, bmi = 35, egfr = 45, bptreat = 1, statin = NA)
#' }
#' ## Calculate predicted risks for an existing data frame called "yourdata" and
#' ## append generated risk scores to original data frame.
#' \donttest{
#'   yourdata <- data.frame(sex = c(1, 0, 1, 0),
#'                        age = c(45, 75, 39, 58),
#'                        tc = c(200, 240, 190, 267),
#'                        hdl = c(60, 90, 50, NA),
#'                        sbp = c(120, 130, 110, 150),
#'                        dm  = c(0, 0, 1, 0),
#'                        smoking = c(1, 0, 0, 0),
#'                        bmi = c(25, 30, NA, 35),
#'                        egfr = c(95, 105, 120, 45),
#'                        bptreat = c(0, 1, 0, 1),
#'                        statin = c(0, 1, 0, NA))
#'
#'   riskscores <- prevent_base(yourdata$sex, yourdata$age, yourdata$tc, yourdata$hdl,
#'                yourdata$sbp, yourdata$dm, yourdata$smoking, yourdata$bmi,
#'                yourdata$egfr, yourdata$bptreat, yourdata$statin)
#'
#'   yourdata_riskscores <- cbind(yourdata, riskscores)
#'
#'   print(yourdata_riskscores)
#' }
#'

prevent_base <- function(sex, age, tc, hdl, sbp, dm, smoking, bmi, egfr, bptreat, statin){
  temp_base <- as.data.frame(t(pred_risk_base_v(sex, age, tc, hdl, sbp, dm, smoking, bmi, egfr, bptreat, statin)))
  names(temp_base) <- c("prevent_base_10yr_CVD",
                        "prevent_base_10yr_ASCVD",
                        "prevent_base_10yr_HF",
                        "prevent_base_30yr_CVD",
                        "prevent_base_30yr_ASCVD",
                        "prevent_base_30yr_HF")
  return(temp_base)
}

#' @name pred_risk_full
#' @title pred_risk_full
#' @param sex Sex, numeric.
#' \itemize{
#'     \item 0 = male
#'     \item 1 = female
#'  }
#' @param age Age (30-79 yrs), numeric.
#' @param tc Total cholesterol (130-320 mg/dL), numeric.
#'
#' \emph{Used in the calculation of non-HDL cholesterol for input into equations, where non-HDL = TC - HDL}.
#' @param hdl High density lipoprotein cholesterol (20-100 mg/dL), numeric.
#' @param sbp Systolic blood pressure (90-200 mmHg), numeric.
#' @param dm Diabetes status (0 or 1), numeric.
#' \itemize{
#'     \item 0 = no history of diabetes
#'     \item 1 = any history of diabetes
#' }
#' @param smoking Smoking status (0 or 1), numeric.
#' \itemize{
#'    \item 0 = non-smoking individual
#'    \item 1 = current smoking
#' }
#' @param bmi Body mass index (18.5-39.9 kg/m^2), numeric.
#' @param egfr Estimated glomerular filtration rate (>0 mL/min/1.73m^2), numeric.
#'
#' \emph{Calculated using the 2021 CKD-EPI creatinine equation (Inker et al., 2021)}.
#' @param bptreat Treatment for hypertension (0 or 1), numeric.
#' \itemize{
#'    \item 0 = no treatment
#'    \item 1 = any treatment
#' }
#' @param statin Statin use (0 or 1), numeric.
#' \itemize{
#'    \item 0 = no statin use
#'    \item 1 = any statin use
#' }
#' @param uacr Urine albumin-creatinine ratio (>=0 mg/g), numeric. If uacr = NA,
#' missing coefficient will be used for uacr.
#' @param hba1c Hemoglobin A1c (>0 percent), numeric. If hba1c = NA, missing
#' coefficient will be used for hba1c.
#' @param sdi Social deprivation index decile (integer 1-10), numeric. The original zip
#' code-based SDI must be recoded as a decile for input into these equations. If sdi = NA,
#' missing coefficient will be used for sdi.
#'
#' \emph{From 2015-2019 American Community Survey Data ("Social deprivation index", 2018).}
#'
#' @keywords internal

pred_risk_full <- function(sex, age, tc, hdl, sbp, dm, smoking, bmi, egfr, bptreat, statin, uacr, hba1c, sdi) {

  if(!all(is.numeric(sex) & (sex %in% c(0, 1)))) {
    prevent_full_30yr_ASCVD = prevent_full_30yr_HF = prevent_full_30yr_CVD = prevent_full_10yr_ASCVD = prevent_full_10yr_HF = prevent_full_10yr_CVD = NA
  } else {
    if(sex==1) {
      logor_10yr_CVD = -3.860385 +
        0.7716794*((age - 55)/10) +
        0.0062109*(mmol_conversion(tc - hdl) - 3.5) -
        0.1547756*(mmol_conversion(hdl) - 1.3)/0.3 -
        0.1933123*(min(sbp, 110) - 110)/20 +
        0.3071217*(max(sbp, 110) - 130)/20 +
        0.496753*(dm) +
        0.466605*(smoking) +
        0.4780697*(min(egfr, 60) - 60)/(-15) +
        0.0529077*(max(egfr, 60) - 90)/(-15) +
        0.3034892*(bptreat) -
        0.1556524*(statin) -
        0.0667026*(bptreat)*(max(sbp, 110) - 130)/20 +
        0.1061825*(statin)*(mmol_conversion(tc - hdl) - 3.5) -
        0.0742271*(age - 55)/10*(mmol_conversion(tc - hdl) - 3.5) +
        0.0288245*(age - 55)/10*(mmol_conversion(hdl) - 1.3)/0.3 -
        0.0875188*(age - 55)/10*(max(sbp, 110) - 130)/20 -
        0.2267102*(age - 55)/10*(dm) -
        0.0676125*(age - 55)/10*(smoking) -
        0.1493231*(age - 55)/10*(min(egfr, 60) - 60)/(-15) +
        (if(!(is.na(sdi))) {0.1361989*(2-sdicat(sdi))*(sdicat(sdi)) +
            0.2261596*(sdicat(sdi)-1)*(0.5*sdicat(sdi))}
         else if (is.na(sdi)) {(0.1804508)}) +
        (if(!(is.na(uacr))) {0.1645922*log(adjust(uacr))}
         else if (is.na(uacr)) {(0.0198413)}) +
        (if(!(is.na(hba1c))) {0.1298513*(hba1c-5.3)*(1-dm) +
            0.1412555*(hba1c-5.3)*(dm)}
         else if (is.na(hba1c)) {(-0.0031658)})

      logor_10yr_ASCVD = -4.291503 +
        0.7023067*((age - 55)/10) +
        0.0898765*((mmol_conversion(tc) - mmol_conversion(hdl)) - 3.5) -
        0.1407316*(mmol_conversion(hdl) - 1.3)/0.3 -
        0.0256648*(min(sbp, 110) - 110)/20 +
        0.314511*(max(sbp, 110) - 130)/20 +
        0.4799217*(dm) +
        0.4062049*(smoking) +
        0.3847744*(min(egfr, 60) - 60)/(-15) +
        0.0495174*(max(egfr, 60) - 90)/(-15) +
        0.2133861*(bptreat) -
        0.0678552*(statin) -
        0.0451416*(bptreat)*(max(sbp, 110) - 130)/20 +
        0.0788187*(statin)*((mmol_conversion(tc) - mmol_conversion(hdl)) - 3.5) -
        0.0535985*(age - 55)/10*((mmol_conversion(tc) - mmol_conversion(hdl)) - 3.5) +
        0.0291762*(age - 55)/10*(mmol_conversion(hdl) - 1.3)/0.3 -
        0.0961839*(age - 55)/10*(max(sbp, 110) - 130)/20 -
        0.2001466*(age - 55)/10*(dm) -
        0.0586472*(age - 55)/10*(smoking) -
        0.1537791*(age - 55)/10*(min(egfr, 60) - 60)/(-15) +
        (if(!(is.na(sdi))) {0.1413965*((2 - sdicat(sdi))*(sdicat(sdi))) +
            0.228136*((sdicat(sdi)-1)*(0.5*sdicat(sdi)))}
         else if (is.na(sdi)) {(0.1588908)}) +
        (if(!(is.na(uacr))) {0.1371824*log(adjust(uacr))}
         else if (is.na(uacr)) {(0.0061613)}) +
        (if(!(is.na(hba1c))) {0.123192*(hba1c-5.3)*(1-dm) +
            0.1410572*(hba1c-5.3)*(dm)}
         else if (is.na(hba1c)) {(0.005866)})

      logor_10yr_HF = -4.896524 +
        0.884209*((age - 55)/10) -
        0.421474*(min(sbp, 110) - 110)/20 +
        0.3002919*(max(sbp, 110) - 130)/20 +
        0.6170359*(dm) +
        0.5380269*(smoking) -
        0.0191335*(min(bmi, 30) - 25)/5 +
        0.2764302*(max(bmi, 30) - 30)/5 +
        0.5975847*(min(egfr, 60) - 60)/(-15) +
        0.0654197*(max(egfr, 60) - 90)/(-15) +
        0.3313614*(bptreat) -
        0.1002304*(bptreat)*(max(sbp, 110) - 130)/20 -
        0.0845363*(age - 55)/10*(max(sbp, 110) - 130)/20 -
        0.2989062*(age - 55)/10*(dm) -
        0.1111354*(age - 55)/10*(smoking) +
        0.0008104*(age - 55)/10*(max(bmi, 30) - 30)/5 -
        0.1666635*(age - 55)/10*(min(egfr, 60) - 60)/(-15) +
        (if(!(is.na(sdi))) {0.1213034*((2 - sdicat(sdi))*(sdicat(sdi))) +
            0.2314147*((sdicat(sdi)-1)*(0.5*sdicat(sdi)))}
         else if (is.na(sdi)) {(0.1819138)}) +
        (if(!(is.na(uacr))) {0.1948135*log(adjust(uacr))}
         else if (is.na(uacr)) {(0.0395368)}) +
        (if(!(is.na(hba1c))) {0.176668*(hba1c-5.3)*(1-dm) +
            0.1614911*(hba1c-5.3)*(dm)}
         else if (is.na(hba1c)) {(-0.0010583)})

      logor_30yr_CVD = -1.748475 +
        0.5073749*((age - 55)/10) -
        0.0981751*(((age - 55)/10)^2) +
        0.0162303*(mmol_conversion(tc - hdl) - 3.5) -
        0.1617147*(mmol_conversion(hdl) - 1.3)/0.3 -
        0.1111241*(min(sbp, 110) - 110)/20 +
        0.282946*(max(sbp, 110) - 130)/20 +
        0.4004069*(dm) +
        0.2918701*(smoking) +
        0.1017102*(min(egfr, 60) - 60)/(-15) +
        0.0622643*(max(egfr, 60) - 90)/(-15) +
        0.2872416*(bptreat) -
        0.0768135*(statin) -
        0.0557282*(bptreat)*(max(sbp, 110) - 130)/20 +
        0.0917585*(statin)*(mmol_conversion(tc - hdl) - 3.5) -
        0.0679131*(age - 55)/10*(mmol_conversion(tc - hdl) - 3.5) +
        0.029076*(age - 55)/10*(mmol_conversion(hdl) - 1.3)/0.3 -
        0.0907755*(age - 55)/10*(max(sbp, 110) - 130)/20 -
        0.2702118*(age - 55)/10*(dm) -
        0.1373216*(age - 55)/10*(smoking) -
        0.1255864*(age - 55)/10*(min(egfr, 60) - 60)/(-15) +
        (if(!(is.na(sdi))) {0.1067741*(2 - sdicat(sdi))*( sdicat(sdi)) +
            0.1853138*(sdicat(sdi)-1)*(0.5*sdicat(sdi))}
         else if (is.na(sdi)) {(0.1567115)}) +
        (if(!(is.na(uacr))) {0.1028065*log(adjust(uacr))}
         else if (is.na(uacr)) {(-0.0006181)}) +
        (if(!(is.na(hba1c))) {0.0925285*(hba1c-5.3)*(1-dm) +
            0.0975598*(hba1c-5.3)*(dm)}
         else if (is.na(hba1c)) {(0.0101713)})

      logor_30yr_ASCVD = -2.314066 +
        0.4386739*((age - 55)/10) -
        0.0921956*((age - 55)/10) ^ 2 +
        0.0977728*((mmol_conversion(tc) - mmol_conversion(hdl))- 3.5) -
        0.1453525*(mmol_conversion(hdl)- 1.3)/0.3 +
        0.0590925*(min(sbp, 110) - 110)/20 +
        0.2862862*(max(sbp, 110) - 130)/20 +
        0.3669136*(dm) +
        0.2354695*(smoking) +
        0.0354338*(min(egfr, 60) - 60)/(-15) +
        0.0573093*(max(egfr, 60) - 90)/(-15) +
        0.1840085*(bptreat) +
        0.0117504*(statin) -
        0.0331945*(bptreat)*(max(sbp, 110) - 130)/20 +
        0.0664311*(statin)*((mmol_conversion(tc) - mmol_conversion(hdl))- 3.5) -
        0.0492826*(age - 55)/10*((mmol_conversion(tc) - mmol_conversion(hdl))- 3.5) +
        0.0288888*(age - 55)/10*(mmol_conversion(hdl)- 1.3)/0.3 -
        0.0964709*(age - 55)/10*(max(sbp, 110) - 130)/20 -
        0.2279648*(age - 55)/10*(dm) -
        0.120405*(age - 55)/10*(smoking) -
        0.1157635*(age - 55)/10*(min(egfr, 60) - 60)/(-15) +
        (if(!(is.na(sdi))) {0.1107632*((2 - sdicat(sdi))*(sdicat(sdi))) +
            0.1840367*((sdicat(sdi)-1)*(0.5*sdicat(sdi)))}
         else if (is.na(sdi)) {(0.1308962)}) +
        (if(!(is.na(uacr))) {0.0810739*log(adjust(uacr))}
         else if (is.na(uacr)) {(-0.0147785)}) +
        (if(!(is.na(hba1c))) {0.0794709*(hba1c-5.3)*(1-dm) +
            0.1002615*(hba1c-5.3)*(dm)}
         else if (is.na(hba1c)) {(0.017301)})

      logor_30yr_HF = -2.642208 +
        0.5927507*((age - 55)/10) -
        0.1028754*((age - 55)/10) ^ 2 -
        0.3593781*(min(sbp, 110) - 110)/20 +
        0.2628556*(max(sbp, 110) - 130)/20 +
        0.5113472*(dm) +
        0.347344*(smoking) +
        0.0564656*(min(bmi, 30) - 25)/5 +
        0.2363857*(max(bmi, 30) - 30)/5 +
        0.1971295*(min(egfr, 60) - 60)/(-15) +
        0.0735227*(max(egfr, 60) - 90)/(-15) +
        0.3219386*(bptreat) -
        0.0880321*(bptreat)*(max(sbp, 110) - 130)/20 -
        0.0863132*(age - 55)/10*(max(sbp, 110) - 130)/20 -
        0.3425359*(age - 55)/10*(dm) -
        0.181405*(age - 55)/10*(smoking) +
        0.0031285*(age - 55)/10*(max(bmi, 30) - 30)/5 -
        0.1356989*(age - 55)/10*(min(egfr, 60) - 60)/(-15) +
        (if(!(is.na(sdi))) {0.0847634*((2 - sdicat(sdi))*(sdicat(sdi))) +
            0.18397*((sdicat(sdi)-1)*(0.5*sdicat(sdi)))}
         else if (is.na(sdi)) {(0.1485802)}) +
        (if(!(is.na(uacr))) {0.1273306*log(adjust(uacr))}
         else if (is.na(uacr)) {(0.0167008)}) +
        (if(!(is.na(hba1c))) {0.1378342*(hba1c-5.3)*(1-dm) +
            0.1138832*(hba1c-5.3)*(dm)}
         else if (is.na(hba1c)) {(0.0138979)})
    }
    else {
      logor_10yr_CVD = -3.631387 +
        0.7847578*((age - 55)/10) +
        0.0534485*(mmol_conversion(tc - hdl) - 3.5) -
        0.0911282*(mmol_conversion(hdl) - 1.3)/0.3 -
        0.4921973*(min(sbp, 110) - 110)/20 +
        0.2972415*(max(sbp, 110) - 130)/20 +
        0.4527054*(dm) +
        0.3726641*(smoking) +
        0.3886854*(min(egfr, 60) - 60)/(-15) +
        0.0081661*(max(egfr, 60) - 90)/(-15) +
        0.2508052*(bptreat) -
        0.1538484*(statin) -
        0.0474695*(bptreat)*(max(sbp, 110) - 130)/20 +
        0.1415382*(statin)*(mmol_conversion(tc - hdl) - 3.5) -
        0.0436455*(age - 55)/10*(mmol_conversion(tc - hdl) - 3.5) +
        0.0199549*(age - 55)/10*(mmol_conversion(hdl) - 1.3)/0.3 -
        0.1022686*(age - 55)/10*(max(sbp, 110) - 130)/20 -
        0.1762507*(age - 55)/10*(dm) -
        0.0715873*(age - 55)/10*(smoking) -
        0.1428668*(age - 55)/10*(min(egfr, 60) - 60)/(-15) +
        (if(!(is.na(sdi))) {0.0802431*(2-sdicat(sdi))*(sdicat(sdi))  +
            0.275073*(sdicat(sdi)-1)*(0.5*sdicat(sdi))}
         else if (is.na(sdi)) {(0.144759)}) +
        (if(!(is.na(uacr))) {0.1772853*log(adjust(uacr))}
         else if (is.na(uacr)) {(0.1095674)}) +
        (if(!(is.na(hba1c))) {0.1165698*(hba1c-5.3)*(1-dm) +
            0.1048297*(hba1c-5.3)*(dm)}
         else if (is.na(hba1c)) {(-0.0230072)})

      logor_10yr_ASCVD = -3.969788 +
        0.7128741*((age - 55)/10) +
        0.1465201*((mmol_conversion(tc) - mmol_conversion(hdl)) - 3.5) -
        0.1125794*(mmol_conversion(hdl) - 1.3)/0.3 -
        0.3387216*(min(sbp, 110) - 110)/20 +
        0.2980252*(max(sbp, 110) - 130)/20 +
        0.399583*(dm) +
        0.3379111*(smoking) +
        0.2582604*(min(egfr, 60) - 60)/(-15) +
        0.0147769*(max(egfr, 60) - 90)/(-15) +
        0.1686621*(bptreat) -
        0.1073619*(statin) -
        0.0381038*(bptreat)*(max(sbp, 110) - 130)/20 +
        0.1034169*(statin)*((mmol_conversion(tc) - mmol_conversion(hdl)) - 3.5) -
        0.0228755*(age - 55)/10*((mmol_conversion(tc) - mmol_conversion(hdl)) - 3.5) +
        0.0267453*(age - 55)/10*(mmol_conversion(hdl) - 1.3)/0.3 -
        0.0897449*(age - 55)/10*(max(sbp, 110) - 130)/20 -
        0.1497464*(age - 55)/10*(dm) -
        0.077206*(age - 55)/10*(smoking) -
        0.1198368*(age - 55)/10*(min(egfr, 60) - 60)/(-15) +
        (if(!(is.na(sdi))) {0.0651121*((2 - sdicat(sdi))*(sdicat(sdi))) +
            0.2676683*((sdicat(sdi)-1)*(0.5*sdicat(sdi)))}
         else if (is.na(sdi)) {(0.1388492)}) +
        (if(!(is.na(uacr))) {0.1375837*log(adjust(uacr))}
         else if (is.na(uacr)) {(0.0652944)}) +
        (if(!(is.na(hba1c))) {0.101282*(hba1c-5.3)*(1-dm) +
            0.1092726*(hba1c-5.3)*(dm)}
         else if (is.na(hba1c)) {(-0.0112852)})

      logor_10yr_HF = -4.663513 +
        0.9095703*((age - 55)/10) -
        0.6765184*(min(sbp, 110) - 110)/20 +
        0.3111651*(max(sbp, 110) - 130)/20 +
        0.5535052*(dm) +
        0.4326811*(smoking) -
        0.0854286*(min(bmi, 30) - 25)/5 +
        0.3551736*(max(bmi, 30) - 30)/5 +
        0.5102245*(min(egfr, 60) - 60)/(-15) +
        0.015472*(max(egfr, 60) - 90)/(-15) +
        0.2570964*(bptreat) -
        0.0591177*(bptreat)*(max(sbp, 110) - 130)/20 -
        0.1219056*(age - 55)/10*(max(sbp, 110) - 130)/20 -
        0.2437577*(age - 55)/10*(dm) -
        0.105363*(age - 55)/10*(smoking) +
        0.0037907*(age - 55)/10*(max(bmi, 30) - 30)/5 -
        0.1660207*(age - 55)/10*(min(egfr, 60) - 60)/(-15) +
        (if(!(is.na(sdi))) {0.1106372*((2 - sdicat(sdi))*(sdicat(sdi))) +
            0.3371204*((sdicat(sdi)-1)*(0.5*sdicat(sdi)))}
         else if (is.na(sdi)) {(0.1694628)}) +
        (if(!(is.na(uacr))) {0.2164607*log(adjust(uacr))}
         else if (is.na(uacr)) {(0.1702805)}) +
        (if(!(is.na(hba1c))) {0.148297*(hba1c-5.3)*(1-dm) +
            0.1234088*(hba1c-5.3)*(dm)}
         else if (is.na(hba1c)) {(-0.0234637)})

      logor_30yr_CVD = -1.504558 +
        0.4427595*((age - 55)/10) -
        0.1064108*(((age - 55)/10)^2) +
        0.0629381*(mmol_conversion(tc - hdl) - 3.5) -
        0.1015427*(mmol_conversion(hdl) - 1.3)/0.3 -
        0.2542326*(min(sbp, 110) - 110)/20 +
        0.2549679*(max(sbp, 110) - 130)/20 +
        0.333835*(dm) +
        0.1873833*(smoking) +
        0.0246102*(min(egfr, 60) - 60)/(-15) +
        0.0552014*(max(egfr, 60) - 90)/(-15) +
        0.1979729*(bptreat) -
        0.0407714*(statin) -
        0.0365522*(bptreat)*(max(sbp, 110) - 130)/20 +
        0.1232822*(statin)*(mmol_conversion(tc - hdl) - 3.5) -
        0.0441334*(age - 55)/10*(mmol_conversion(tc - hdl) - 3.5) +
        0.0177865*(age - 55)/10*(mmol_conversion(hdl) - 1.3)/0.3 -
        0.1046657*(age - 55)/10*(max(sbp, 110) - 130)/20 -
        0.2116113*(age - 55)/10*(dm) -
        0.1277905*(age - 55)/10*(smoking) -
        0.0955922*(age - 55)/10*(min(egfr, 60) - 60)/(-15) +
        (if(!(is.na(sdi))) {0.0256704*(2 - sdicat(sdi))*(sdicat(sdi)) +
            0.1887637*(sdicat(sdi)-1)*(0.5*sdicat(sdi))}
         else if (is.na(sdi)) {(0.089241)}) +
        (if(!(is.na(uacr))) {0.0894596*log(adjust(uacr))}
         else if (is.na(uacr)) {(0.0710124)}) +
        (if(!(is.na(hba1c))) {0.0676202*(hba1c-5.3)*(1-dm) +
            0.063409*(hba1c-5.3)*(dm)}
         else if (is.na(hba1c)) {(0.0038783)} )

      logor_30yr_ASCVD = -1.985368 +
        0.3743566*((age - 55)/10) -
        0.0995499*((age - 55)/10) ^ 2 +
        0.1544808*((mmol_conversion(tc) - mmol_conversion(hdl))- 3.5) -
        0.1215297*(mmol_conversion(hdl)- 1.3)/0.3 -
        0.1083968*(min(sbp, 110) - 110)/20 +
        0.2555179*(max(sbp, 110) - 130)/20 +
        0.2696998*(dm) +
        0.1628432*(smoking) -
        0.077507*(min(egfr, 60) - 60)/(-15) +
        0.0583407*(max(egfr, 60) - 90)/(-15) +
        0.1120322*(bptreat) -
        0.0025063*(statin) -
        0.0256116*(bptreat)*(max(sbp, 110) - 130)/20 +
        0.0886745*(statin)*((mmol_conversion(tc) - mmol_conversion(hdl))- 3.5) -
        0.0254507*(age - 55)/10*((mmol_conversion(tc) - mmol_conversion(hdl))- 3.5) +
        0.0244639*(age - 55)/10*(mmol_conversion(hdl)- 1.3)/0.3 -
        0.0869146*(age - 55)/10*(max(sbp, 110) - 130)/20 -
        0.165745*(age - 55)/10*(dm) -
        0.1244714*(age - 55)/10*(smoking) -
        0.0624552*(age - 55)/10*(min(egfr, 60) - 60)/(-15) +
        (if(!(is.na(sdi))) {0.015675*((2 - sdicat(sdi))*(sdicat(sdi))) +
            0.1864231*((sdicat(sdi)-1)*(0.5*sdicat(sdi)))}
         else if (is.na(sdi)) {(0.0845697)}) +
        (if(!(is.na(uacr))) {0.0560171*log(adjust(uacr))}
         else if (is.na(uacr)) {(0.0252244)}) +
        (if(!(is.na(hba1c))) {0.0501422*(hba1c-5.3)*(1-dm) +
            0.0722905*(hba1c-5.3)*(dm)}
         else if (is.na(hba1c)) {(0.0114945)})

      logor_30yr_HF = -2.425439 +
        0.5478829*((age - 55)/10) -
        0.1111928*((age - 55)/10) ^ 2 -
        0.4547346*(min(sbp, 110) - 110)/20 +
        0.2527602*(max(sbp, 110) - 130)/20 +
        0.4385384*(dm) +
        0.2397952*(smoking) +
        0.0640931*(min(bmi, 30) - 25)/5 +
        0.2643081*(max(bmi, 30) - 30)/5 +
        0.1354588*(min(egfr, 60) - 60)/(-15) +
        0.0570689*(max(egfr, 60) - 90)/(-15) +
        0.220666*(bptreat) -
        0.0436769*(bptreat)*(max(sbp, 110) - 130)/20 -
        0.1168376*(age - 55)/10*(max(sbp, 110) - 130)/20 -
        0.2730055*(age - 55)/10*(dm) -
        0.1573691*(age - 55)/10*(smoking) -
        0.0174998*(age - 55)/10*(max(bmi, 30) - 30)/5 -
        0.1128676*(age - 55)/10*(min(egfr, 60) - 60)/(-15) +
        (if(!(is.na(sdi))) {0.057746*((2 - sdicat(sdi))*(sdicat(sdi))) +
            0.2446441*((sdicat(sdi)-1)*(0.5*sdicat(sdi)))}
         else if (is.na(sdi)) {(0.1076782)}) +
        (if(!(is.na(uacr))) {0.1233486*log(adjust(uacr))}
         else if (is.na(uacr)) {(0.1274796)}) +
        (if(!(is.na(hba1c))) {0.0985062*(hba1c-5.3)*(1-dm) +
            0.0804844*(hba1c-5.3)*(dm)}
         else if (is.na(hba1c)) {(0.0022806)} )
    }

    prevent_full_10yr_CVD = 100*exp(logor_10yr_CVD) / (1 + exp(logor_10yr_CVD))
    prevent_full_30yr_CVD = 100*exp(logor_30yr_CVD) / (1 + exp(logor_30yr_CVD))
    prevent_full_10yr_ASCVD = 100*exp(logor_10yr_ASCVD) / (1 + exp(logor_10yr_ASCVD))
    prevent_full_30yr_ASCVD = 100*exp(logor_30yr_ASCVD) / (1 + exp(logor_30yr_ASCVD))
    prevent_full_10yr_HF = 100*exp(logor_10yr_HF) / (1 + exp(logor_10yr_HF))
    prevent_full_30yr_HF = 100*exp(logor_30yr_HF) / (1 + exp(logor_30yr_HF))

  }

  if (!is.na(age)) {
    if(age > 59 & age <= 79) {
      prevent_full_30yr_ASCVD = prevent_full_30yr_HF = prevent_full_30yr_CVD = NA
    } else if (age < 30 | age > 79){
      prevent_full_30yr_ASCVD = prevent_full_30yr_HF = prevent_full_30yr_CVD = prevent_full_10yr_ASCVD = prevent_full_10yr_HF = prevent_full_10yr_CVD = NA
    }
  }

  if (is.na(tc) | tc < 130 | tc > 320) { prevent_full_30yr_ASCVD = prevent_full_30yr_CVD = prevent_full_10yr_ASCVD = prevent_full_10yr_CVD = NA
  }

  if (is.na(hdl) | hdl < 20 | hdl > 100) { prevent_full_30yr_ASCVD = prevent_full_30yr_CVD = prevent_full_10yr_ASCVD = prevent_full_10yr_CVD = NA
  }

  if (is.na(sbp) | sbp < 90 | sbp > 200) { prevent_full_30yr_ASCVD = prevent_full_30yr_HF = prevent_full_30yr_CVD = prevent_full_10yr_ASCVD = prevent_full_10yr_HF = prevent_full_10yr_CVD = NA
  }

  if(!(all(is.numeric(dm)) & (dm %in% c(0, 1)))) { prevent_full_30yr_ASCVD = prevent_full_30yr_HF = prevent_full_30yr_CVD = prevent_full_10yr_ASCVD = prevent_full_10yr_HF = prevent_full_10yr_CVD = NA
  }

  if(!(all(is.numeric(smoking)) & (smoking %in% c(0, 1)))) { prevent_full_30yr_ASCVD = prevent_full_30yr_HF = prevent_full_30yr_CVD = prevent_full_10yr_ASCVD = prevent_full_10yr_HF = prevent_full_10yr_CVD = NA
  }

  if (is.na(egfr) | egfr <= 0) { prevent_full_30yr_ASCVD = prevent_full_30yr_HF = prevent_full_30yr_CVD = prevent_full_10yr_ASCVD = prevent_full_10yr_HF = prevent_full_10yr_CVD = NA
  }

  if(!(all(is.numeric(bptreat)) & (bptreat %in% c(0, 1)))) { prevent_full_30yr_ASCVD = prevent_full_30yr_HF = prevent_full_30yr_CVD = prevent_full_10yr_ASCVD = prevent_full_10yr_HF = prevent_full_10yr_CVD = NA
  }

  if(!(all(is.numeric(statin)) & (statin %in% c(0, 1)))) { prevent_full_30yr_ASCVD = prevent_full_30yr_CVD = prevent_full_10yr_ASCVD = prevent_full_10yr_CVD = NA
  }

  if (is.na(bmi) | bmi < 18.5 | bmi >= 40) { prevent_full_30yr_HF = prevent_full_10yr_HF = NA
  }

  if (!is.na(uacr) & (uacr < 0)) { prevent_full_30yr_ASCVD = prevent_full_30yr_HF = prevent_full_30yr_CVD = prevent_full_10yr_ASCVD = prevent_full_10yr_HF = prevent_full_10yr_CVD = NA
  }

  if (!is.na(hba1c) & (hba1c <= 0)) { prevent_full_30yr_ASCVD = prevent_full_30yr_HF = prevent_full_30yr_CVD = prevent_full_10yr_ASCVD = prevent_full_10yr_HF = prevent_full_10yr_CVD = NA
  }

  if(!(all(is.numeric(sdi))) & !(all(is.na(sdi)) & (sdi %in% c(NA, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10)))) { prevent_full_30yr_ASCVD = prevent_full_30yr_HF = prevent_full_30yr_CVD = prevent_full_10yr_ASCVD = prevent_full_10yr_HF = prevent_full_10yr_CVD = NA
  }

  prevent_full_values <- data.frame(prevent_full_10yr_CVD = prevent_full_10yr_CVD,
                                    prevent_full_10yr_ASCVD = prevent_full_10yr_ASCVD,
                                    prevent_full_10yr_HF = prevent_full_10yr_HF,
                                    prevent_full_30yr_CVD = prevent_full_30yr_CVD,
                                    prevent_full_30yr_ASCVD = prevent_full_30yr_ASCVD,
                                    prevent_full_30yr_HF = prevent_full_30yr_HF)

  return(prevent_full_values)
}

#' @name pred_risk_full_v
#' @title pred_risk_full_v
#' @param sex Sex, numeric.
#' \itemize{
#'     \item 0 = male
#'     \item 1 = female
#'  }
#' @param age Age (30-79 yrs), numeric.
#' @param tc Total cholesterol (130-320 mg/dL), numeric.
#'
#' \emph{Used in the calculation of non-HDL cholesterol for input into equations, where non-HDL = TC - HDL}.
#' @param hdl High density lipoprotein cholesterol (20-100 mg/dL), numeric.
#' @param sbp Systolic blood pressure (90-200 mmHg), numeric.
#' @param dm Diabetes status (0 or 1), numeric.
#' \itemize{
#'     \item 0 = no history of diabetes
#'     \item 1 = any history of diabetes
#' }
#' @param smoking Smoking status (0 or 1), numeric.
#' \itemize{
#'    \item 0 = non-smoking individual
#'    \item 1 = current smoking
#' }
#' @param bmi Body mass index (18.5-39.9 kg/m^2), numeric.
#' @param egfr Estimated glomerular filtration rate (>0 mL/min/1.73m^2), numeric.
#'
#' \emph{Calculated using the 2021 CKD-EPI creatinine equation (Inker et al., 2021)}.
#' @param bptreat Treatment for hypertension (0 or 1), numeric.
#' \itemize{
#'    \item 0 = no treatment
#'    \item 1 = any treatment
#' }
#' @param statin Statin use (0 or 1), numeric.
#' \itemize{
#'    \item 0 = no statin use
#'    \item 1 = any statin use
#' }
#' @param uacr Urine albumin-creatinine ratio (>=0 mg/g), numeric. If uacr = NA,
#' missing coefficient will be used for uacr.
#' @param hba1c Hemoglobin A1c (>0 percent), numeric. If hba1c = NA, missing
#' coefficient will be used for hba1c.
#' @param sdi Social deprivation index decile (integer 1-10), numeric. The original zip
#' code-based SDI must be recoded as a decile for input into these equations. If sdi = NA,
#' missing coefficient will be used for sdi.
#'
#' \emph{From 2015-2019 American Community Survey Data ("Social deprivation index", 2018).}
#'
#' @keywords internal

pred_risk_full_v <- Vectorize(pred_risk_full)

#' @description \strong{prevent_full} returns the predicted risks (absolute risk, percent)
#' using the PREVENT full equation. \cr
#' @details Individuals missing any required input variables (sex, age, sbp, dm, smoking, egfr, bptreat)
#' will return "NA" since these are required variables to calculate risk estimates. Cholesterol variables (tc, hdl, statin)
#' are required for total CVD and ASCVD risk calculations while bmi is required for HF risk
#' calculation; individuals missing these variables will return "NA" only for the calculation of risks
#' requiring the input. For uacr, hba1c, and sdi, missing coefficients are available and may be used
#' when using "prevent_full". If risk factor levels are out of range based on how this was defined in the development of the
#' equations (Khan et al., 2024), a risk estimate will not be calculated and the function will return “NA”.
#'
#' @name prevent_full
#' @title AHA PREVENT full equation
#' @param sex Sex, numeric.
#' \itemize{
#'     \item 0 = male
#'     \item 1 = female
#'  }
#' @param age Age (30-79 yrs), numeric.
#' @param tc Total cholesterol (130-320 mg/dL), numeric.
#'
#' \emph{Used in the calculation of non-HDL cholesterol for input into equations, where non-HDL = TC - HDL}.
#' @param hdl High density lipoprotein cholesterol (20-100 mg/dL), numeric.
#' @param sbp Systolic blood pressure (90-200 mmHg), numeric.
#' @param dm Diabetes status (0 or 1), numeric.
#' \itemize{
#'     \item 0 = no history of diabetes
#'     \item 1 = any history of diabetes
#' }
#' @param smoking Smoking status (0 or 1), numeric.
#' \itemize{
#'    \item 0 = non-smoking individual
#'    \item 1 = current smoking
#' }
#' @param bmi Body mass index (18.5-39.9 kg/m^2), numeric.
#' @param egfr Estimated glomerular filtration rate (>0 mL/min/1.73m^2), numeric.
#'
#' \emph{Calculated using the 2021 CKD-EPI creatinine equation (Inker et al., 2021)}.
#' @param bptreat Treatment for hypertension (0 or 1), numeric.
#' \itemize{
#'    \item 0 = no treatment
#'    \item 1 = any treatment
#' }
#' @param statin Statin use (0 or 1), numeric.
#' \itemize{
#'    \item 0 = no statin use
#'    \item 1 = any statin use
#' }
#' @param uacr Urine albumin-creatinine ratio (>=0 mg/g), numeric. If uacr = NA,
#' missing coefficient will be used for uacr.
#' @param hba1c Hemoglobin A1c (>0 percent), numeric. If hba1c = NA,
#' missing coefficient will be used for hba1c.
#' @param sdi Social deprivation index decile (integer 1-10), numeric. The original
#' zip code-based SDI must be recoded as a decile for input into these equations. If sdi = NA,
#' missing coefficient will be used for sdi.
#'
#' \emph{From 2015-2019 American Community Survey Data ("Social deprivation index", 2018).}
#'
#' @returns Data frame containing six variables: prevent_full_10yr_CVD,
#' prevent_full_30yr_CVD, prevent_full_10yr_ASCVD,
#' prevent_full_30yr_ASCVD, prevent_full_10yr_HF, and prevent_full_30yr_HF.
#' \itemize{
#'    \item prevent_full_10yr_CVD = Predicted 10-year Total CVD risk
#'    \item prevent_full_30yr_CVD = Predicted 30-year Total CVD risk
#'    \item prevent_full_10yr_ASCVD = Predicted 10-year ASCVD risk
#'    \item prevent_full_30yr_ASCVD = Predicted 30-year ASCVD risk
#'    \item prevent_full_10yr_HF = Predicted 10-year HF risk
#'    \item prevent_full_30yr_HF = Predicted 30-year HF risk
#' }
#'
#' @export
#'
#' @examples
#' ## Calculate predicted risks for a 45-year-old woman with a TC of 200 mg/dL
#' ## and HDL-C of 60 mg/dL (not on statin therapy), a systolic blood pressure of
#' ## 120 mm Hg (not on anti-hypertensive treatment), has diabetes, does not smoke,
#' ## with a BMI of 25 kg/m^2, eGFR of 95 mL/min/1.73m^2, UACR of 10 mg/g,
#' ## HbA1c of 7%, and SDI decile of 4.
#' \donttest{
#'   prevent_full(sex = 1, age = 45, tc = 200, hdl = 60, sbp = 120, dm = 1,
#'   smoking = 0, bmi = 25, egfr = 95, bptreat = 0, statin = 0, uacr = 10,
#'   hba1c = 7, sdi = 4)
#' }
#' ## Calculate predicted 10-year risks only for 75-year old man
#' ## (no 30-year risks calculated due to age > 75).
#' \donttest{
#'   prevent_full(sex = 0, age = 75, tc = 250, hdl = 90, sbp = 130, dm = 0,
#'   smoking = 1, bmi = 30, egfr = 105, bptreat = 0, statin = 1, uacr = 50,
#'   hba1c = 4, sdi = 2)
#' }
#' ## Calculate predicted total CVD and ASCVD risks only for 39-year old woman
#' ## (no HF risks calculated due to missing BMI).
#' \donttest{
#'   prevent_full(sex = 1, age = 39, tc = 190, hdl = 50, sbp = 110, dm = 1,
#'   smoking = 0, bmi = NA, egfr = 120, bptreat = 0, statin = 0, uacr = 5,
#'   hba1c = 13, sdi = 3)
#' }
#' ## Calculate predicted HF risks only for 58-year old man
#' ## (no CVD/ASCVD risks calculated due to missing cholesterol/statin variables).
#' \donttest{
#'   prevent_full(sex = 0, age = 58, tc = 230, hdl = NA, sbp = 150, dm = 0,
#'   smoking = 0, bmi = 35, egfr = 45, bptreat = 1, statin = NA, uacr = 150,
#'   hba1c = 5.3, sdi = 8)
#' }
#' ## Calculate predicted risks for an existing data frame called "yourdata" and
#' ## append generated risk scores to original data frame.
#' \donttest{
#'   yourdata <- data.frame(sex = c(1, 0, 1, 0),
#'                        age = c(45, 75, 39, 58),
#'                        tc = c(200, 240, 190, 267),
#'                        hdl = c(60, 90, 50, NA),
#'                        sbp = c(120, 130, 110, 150),
#'                        dm  = c(0, 0, 1, 0),
#'                        smoking = c(1, 0, 0, 0),
#'                        bmi = c(25, 30, NA, 35),
#'                        egfr = c(95, 105, 120, 45),
#'                        bptreat = c(0, 1, 0, 1),
#'                        statin = c(0, 1, 0, NA),
#'                        uacr = c(150, 10, 500, 45),
#'                        hba1c = c(8.5, 4, 6, 10.5),
#'                        sdi = c(9, 3, 5, 8))
#'
#'   riskscores <- prevent_full(yourdata$sex, yourdata$age, yourdata$tc, yourdata$hdl,
#'                yourdata$sbp, yourdata$dm, yourdata$smoking, yourdata$bmi,
#'                yourdata$egfr, yourdata$bptreat, yourdata$statin,
#'                yourdata$uacr, yourdata$hba1c, yourdata$sdi)
#'
#'   yourdata_riskscores <- cbind(yourdata, riskscores)
#'
#'   print(yourdata_riskscores)
#' }
#'

prevent_full <- function(sex, age, tc, hdl, sbp, dm, smoking, bmi, egfr, bptreat, statin, uacr, hba1c, sdi){
  temp_full <- as.data.frame(t(pred_risk_full_v(sex, age, tc, hdl, sbp, dm, smoking, bmi, egfr, bptreat, statin, uacr, hba1c, sdi)))
  names(temp_full) <- c("prevent_full_10yr_CVD",
                        "prevent_full_10yr_ASCVD",
                        "prevent_full_10yr_HF",
                        "prevent_full_30yr_CVD",
                        "prevent_full_30yr_ASCVD",
                        "prevent_full_30yr_HF")
  return(temp_full)
}

#' @name pred_risk_uacr
#' @title pred_risk_uacr
#' @param sex Sex, numeric.
#' \itemize{
#'     \item 0 = male
#'     \item 1 = female
#'  }
#' @param age Age (30-79 yrs), numeric.
#' @param tc Total cholesterol (130-320 mg/dL), numeric.
#'
#' \emph{Used in the calculation of non-HDL cholesterol for input into equations, where non-HDL = TC - HDL}.
#' @param hdl High density lipoprotein cholesterol (20-100 mg/dL), numeric.
#' @param sbp Systolic blood pressure (90-200 mmHg), numeric.
#' @param dm Diabetes status (0 or 1), numeric.
#' \itemize{
#'     \item 0 = no history of diabetes
#'     \item 1 = any history of diabetes
#' }
#' @param smoking Smoking status (0 or 1), numeric.
#' \itemize{
#'    \item 0 = non-smoking individual
#'    \item 1 = current smoking
#' }
#' @param bmi Body mass index (18.5-39.9 kg/m^2), numeric.
#' @param egfr Estimated glomerular filtration rate (>0 mL/min/1.73m^2), numeric.
#'
#' \emph{Calculated using the 2021 CKD-EPI creatinine equation (Inker et al., 2021)}.
#' @param bptreat Treatment for hypertension (0 or 1), numeric.
#' \itemize{
#'    \item 0 = no treatment
#'    \item 1 = any treatment
#' }
#' @param statin Statin use (0 or 1), numeric.
#' \itemize{
#'    \item 0 = no statin use
#'    \item 1 = any statin use
#' }
#' @param uacr Urine albumin-creatinine ratio (>=0 mg/g), numeric. If uacr = NA,
#' missing coefficient will be used for uacr.
#'
#' @keywords internal

pred_risk_uacr <- function(sex, age, tc, hdl, sbp, dm, smoking, bmi, egfr, bptreat, statin, uacr) {

  if(!all(is.numeric(sex) & (sex %in% c(0, 1)))) {
    prevent_uacr_30yr_ASCVD = prevent_uacr_30yr_HF = prevent_uacr_30yr_CVD = prevent_uacr_10yr_ASCVD = prevent_uacr_10yr_HF = prevent_uacr_10yr_CVD = NA
  } else {
    if(sex==1) {
      logor_10yr_CVD = -3.738341 +
        0.7969249*((age - 55)/10) +
        0.0256635*((mmol_conversion(tc) - mmol_conversion(hdl)) - 3.5) -
        0.1588107*(mmol_conversion(hdl) - 1.3)/0.3 -
        0.2255701*(min(sbp, 110) - 110)/20 +
        0.3396649*(max(sbp, 110) - 130)/20 +
        0.8047515*(dm) +
        0.5285338*(smoking) +
        0.4803511*(min(egfr, 60) - 60)/(-15) +
        0.0434472*(max(egfr, 60) - 90)/(-15) +
        0.2985207*(bptreat) -
        0.1497787*(statin) -
        0.0742889*(bptreat)*(max(sbp, 110) - 130)/20 +
        0.106756*(statin)*((mmol_conversion(tc) - mmol_conversion(hdl)) - 3.5) -
        0.0778126*(age - 55)/10*((mmol_conversion(tc) - mmol_conversion(hdl)) - 3.5) +
        0.0306768*(age - 55)/10*(mmol_conversion(hdl) - 1.3)/0.3 -
        0.0907168*(age - 55)/10*(max(sbp, 110) - 130)/20 -
        0.2705122*(age - 55)/10*(dm) -
        0.0830564*(age - 55)/10*(smoking) -
        0.1389249*(age - 55)/10*(min(egfr, 60) - 60)/(-15) +
        if(!(is.na(uacr))) {0.1793037*log(adjust(uacr))}
      else if (is.na(uacr)) {(0.0132073)}

      logor_10yr_ASCVD = -4.174614 +
        0.7201999*((age - 55)/10) +
        0.1135771*((mmol_conversion(tc) - mmol_conversion(hdl)) - 3.5) -
        0.1493506*(mmol_conversion(hdl) - 1.3)/0.3 -
        0.0726677*(min(sbp, 110) - 110)/20 +
        0.3436259*(max(sbp, 110) - 130)/20 +
        0.7773094*(dm) +
        0.4746662*(smoking) +
        0.3824646*(min(egfr, 60) - 60)/(-15) +
        0.0394178*(max(egfr, 60) - 90)/(-15) +
        0.2125182*(bptreat) -
        0.0603046*(statin) -
        0.0466053*(bptreat)*(max(sbp, 110) - 130)/20 +
        0.0733118*(statin)*((mmol_conversion(tc) - mmol_conversion(hdl)) - 3.5) -
        0.0534262*(age - 55)/10*((mmol_conversion(tc) - mmol_conversion(hdl)) - 3.5) +
        0.0325689*(age - 55)/10*(mmol_conversion(hdl) - 1.3)/0.3 -
        0.0999887*(age - 55)/10*(max(sbp, 110) - 130)/20 -
        0.2411762*(age - 55)/10*(dm) -
        0.0826941*(age - 55)/10*(smoking) -
        0.1444737*(age - 55)/10*(min(egfr, 60) - 60)/(-15) +
        if(!(is.na(uacr))) {0.1501217*log(adjust(uacr))}
      else if (is.na(uacr)) {(0.0050257)}

      logor_10yr_HF = -4.841506 +
        0.9145975*((age - 55)/10) -
        0.4441346*(min(sbp, 110) - 110)/20 +
        0.3260323*(max(sbp, 110) - 130)/20 +
        0.9611365*(dm) +
        0.5755787*(smoking) +
        0.0008831*(min(bmi, 30) - 25)/5 +
        0.2988964*(max(bmi, 30) - 30)/5 +
        0.5915291*(min(egfr, 60) - 60)/(-15) +
        0.0556823*(max(egfr, 60) - 90)/(-15) +
        0.3314097*(bptreat) -
        0.1078596*(bptreat)*(max(sbp, 110) - 130)/20 -
        0.0875231*(age - 55)/10*(max(sbp, 110) - 130)/20 -
        0.356859*(age - 55)/10*(dm) -
        0.1220248*(age - 55)/10*(smoking) -
        0.0053637*(age - 55)/10*(max(bmi, 30) - 30)/5 -
        0.1610389*(age - 55)/10*(min(egfr, 60) - 60)/(-15) +
        if(!(is.na(uacr))) {0.2197281*log(adjust(uacr))}
      else if (is.na(uacr)) {(0.0326667)}

      logor_30yr_CVD = -1.583738 +
        0.5491768*((age - 55)/10) -
        0.0937311*((age - 55)/10) ^ 2 +
        0.0359847*((mmol_conversion(tc) - mmol_conversion(hdl))- 3.5) -
        0.1642965*(mmol_conversion(hdl)- 1.3)/0.3 -
        0.1483404*(min(sbp, 110) - 110)/20 +
        0.313353*(max(sbp, 110) - 130)/20 +
        0.6253766*(dm) +
        0.3147172*(smoking) +
        0.1094663*(min(egfr, 60) - 60)/(-15) +
        0.0550705*(max(egfr, 60) - 90)/(-15) +
        0.2782433*(bptreat) -
        0.0786239*(statin) -
        0.0628947*(bptreat)*(max(sbp, 110) - 130)/20 +
        0.093204*(statin)*((mmol_conversion(tc) - mmol_conversion(hdl))- 3.5) -
        0.0710685*(age - 55)/10*((mmol_conversion(tc) - mmol_conversion(hdl))- 3.5) +
        0.0306363*(age - 55)/10*(mmol_conversion(hdl)- 1.3)/0.3 -
        0.0951455*(age - 55)/10*(max(sbp, 110) - 130)/20 -
        0.3168231*(age - 55)/10*(dm) -
        0.1636391*(age - 55)/10*(smoking) -
        0.1265483*(age - 55)/10*(min(egfr, 60) - 60)/(-15) +
        if(!(is.na(uacr))) {0.1142251*log(adjust(uacr))}
      else if (is.na(uacr)) {(-0.0055863)}

      logor_30yr_ASCVD = -2.178888 +
        0.4629669*((age - 55)/10) -
        0.0902777*((age - 55)/10) ^ 2 +
        0.1215214*((mmol_conversion(tc) - mmol_conversion(hdl))- 3.5) -
        0.1522069*(mmol_conversion(hdl)- 1.3)/0.3 +
        0.0092679*(min(sbp, 110) - 110)/20 +
        0.3113609*(max(sbp, 110) - 130)/20 +
        0.581256*(dm) +
        0.263167*(smoking) +
        0.0391726*(min(egfr, 60) - 60)/(-15) +
        0.0492959*(max(egfr, 60) - 90)/(-15) +
        0.1786178*(bptreat) +
        0.0131058*(statin) -
        0.0325135*(bptreat)*(max(sbp, 110) - 130)/20 +
        0.0617093*(statin)*((mmol_conversion(tc) - mmol_conversion(hdl))- 3.5) -
        0.0489189*(age - 55)/10*((mmol_conversion(tc) - mmol_conversion(hdl))- 3.5) +
        0.0321079*(age - 55)/10*(mmol_conversion(hdl)- 1.3)/0.3 -
        0.1003185*(age - 55)/10*(max(sbp, 110) - 130)/20 -
        0.2684574*(age - 55)/10*(dm) -
        0.1547301*(age - 55)/10*(smoking) -
        0.1130703*(age - 55)/10*(min(egfr, 60) - 60)/(-15) +
        if(!(is.na(uacr))) {0.0903471*log(adjust(uacr))}
      else if (is.na(uacr)) {(-0.0145818)}

      logor_30yr_HF = -2.538952 +
        0.6319513*((age - 55)/10) -
        0.1009284*((age - 55)/10) ^ 2 -
        0.3787175*(min(sbp, 110) - 110)/20 +
        0.2863393*(max(sbp, 110) - 130)/20 +
        0.7631221*(dm) +
        0.3355843*(smoking) +
        0.0677084*(min(bmi, 30) - 25)/5 +
        0.2517238*(max(bmi, 30) - 30)/5 +
        0.1940067*(min(egfr, 60) - 60)/(-15) +
        0.0664006*(max(egfr, 60) - 90)/(-15) +
        0.3171436*(bptreat) -
        0.0970661*(bptreat)*(max(sbp, 110) - 130)/20 -
        0.0896239*(age - 55)/10*(max(sbp, 110) - 130)/20 -
        0.400743*(age - 55)/10*(dm) -
        0.2042041*(age - 55)/10*(smoking) -
        0.0054699*(age - 55)/10*(max(bmi, 30) - 30)/5 -
        0.13602*(age - 55)/10*(min(egfr, 60) - 60)/(-15) +
        if(!(is.na(uacr))) {0.1486028*log(adjust(uacr))}
      else if (is.na(uacr)) {(0.011608)}
    }
    else {
      logor_10yr_CVD = -3.510705 +
        0.7768655*((age - 55)/10) +
        0.0659949*((mmol_conversion(tc) - mmol_conversion(hdl)) - 3.5) -
        0.0951111*(mmol_conversion(hdl) - 1.3)/0.3 -
        0.420667*(min(sbp, 110) - 110)/20 +
        0.3120151*(max(sbp, 110) - 130)/20 +
        0.698521*(dm) +
        0.4314669*(smoking) +
        0.3841364*(min(egfr, 60) - 60)/(-15) +
        0.009384*(max(egfr, 60) - 90)/(-15) +
        0.2676494*(bptreat) -
        0.1390966*(statin) -
        0.0579315*(bptreat)*(max(sbp, 110) - 130)/20 +
        0.1383719*(statin)*((mmol_conversion(tc) - mmol_conversion(hdl)) - 3.5) -
        0.0488332*(age - 55)/10*((mmol_conversion(tc) - mmol_conversion(hdl)) - 3.5) +
        0.0200406*(age - 55)/10*(mmol_conversion(hdl) - 1.3)/0.3 -
        0.102454*(age - 55)/10*(max(sbp, 110) - 130)/20 -
        0.2236355*(age - 55)/10*(dm) -
        0.089485*(age - 55)/10*(smoking) -
        0.1321848*(age - 55)/10*(min(egfr, 60) - 60)/(-15) +
        if(!(is.na(uacr))) {0.1887974*log(adjust(uacr))}
      else if (is.na(uacr)) {(0.0916979)}

      logor_10yr_ASCVD = -3.85146 +
        0.7141718*((age - 55)/10) +
        0.1602194*((mmol_conversion(tc) - mmol_conversion(hdl)) - 3.5) -
        0.1139086*(mmol_conversion(hdl) - 1.3)/0.3 -
        0.2719456*(min(sbp, 110) - 110)/20 +
        0.3058719*(max(sbp, 110) - 130)/20 +
        0.6600631*(dm) +
        0.3884022*(smoking) +
        0.2466316*(min(egfr, 60) - 60)/(-15) +
        0.0151852*(max(egfr, 60) - 90)/(-15) +
        0.186167*(bptreat) -
        0.0894395*(statin) -
        0.0411884*(bptreat)*(max(sbp, 110) - 130)/20 +
        0.1058212*(statin)*((mmol_conversion(tc) - mmol_conversion(hdl)) - 3.5) -
        0.028089*(age - 55)/10*((mmol_conversion(tc) - mmol_conversion(hdl)) - 3.5) +
        0.0240427*(age - 55)/10*(mmol_conversion(hdl) - 1.3)/0.3 -
        0.0912325*(age - 55)/10*(max(sbp, 110) - 130)/20 -
        0.2004894*(age - 55)/10*(dm) -
        0.096936*(age - 55)/10*(smoking) -
        0.1022867*(age - 55)/10*(min(egfr, 60) - 60)/(-15) +
        if(!(is.na(uacr))) {0.1510073*log(adjust(uacr))}
      else if (is.na(uacr)) {(0.0556)}

      logor_10yr_HF = -4.556907 +
        0.9111795*((age - 55)/10) -
        0.6693649*(min(sbp, 110) - 110)/20 +
        0.3290082*(max(sbp, 110) - 130)/20 +
        0.8377655*(dm) +
        0.4978917*(smoking) -
        0.042749*(min(bmi, 30) - 25)/5 +
        0.3624165*(max(bmi, 30) - 30)/5 +
        0.5075796*(min(egfr, 60) - 60)/(-15) +
        0.0137716*(max(egfr, 60) - 90)/(-15) +
        0.2739963*(bptreat) -
        0.0645712*(bptreat)*(max(sbp, 110) - 130)/20 -
        0.1230039*(age - 55)/10*(max(sbp, 110) - 130)/20 -
        0.3013297*(age - 55)/10*(dm) -
        0.1410318*(age - 55)/10*(smoking) +
        0.0021531*(age - 55)/10*(max(bmi, 30) - 30)/5 -
        0.1548018*(age - 55)/10*(min(egfr, 60) - 60)/(-15) +
        if(!(is.na(uacr))) {0.2306299*log(adjust(uacr))}
      else if (is.na(uacr)) {(0.1472194)}

      logor_30yr_CVD = -1.398727 +
        0.464491*((age - 55)/10) -
        0.0998895*((age - 55)/10) ^ 2 +
        0.0757606*((mmol_conversion(tc) - mmol_conversion(hdl))- 3.5) -
        0.1031778*(mmol_conversion(hdl)- 1.3)/0.3 -
        0.1990714*(min(sbp, 110) - 110)/20 +
        0.2715816*(max(sbp, 110) - 130)/20 +
        0.4754637*(dm) +
        0.2069672*(smoking) +
        0.0331103*(min(egfr, 60) - 60)/(-15) +
        0.0540474*(max(egfr, 60) - 90)/(-15) +
        0.2189911*(bptreat) -
        0.0331044*(statin) -
        0.04534*(bptreat)*(max(sbp, 110) - 130)/20 +
        0.1214535*(statin)*((mmol_conversion(tc) - mmol_conversion(hdl))- 3.5) -
        0.0483995*(age - 55)/10*((mmol_conversion(tc) - mmol_conversion(hdl))- 3.5) +
        0.0178997*(age - 55)/10*(mmol_conversion(hdl)- 1.3)/0.3 -
        0.1059324*(age - 55)/10*(max(sbp, 110) - 130)/20 -
        0.2492861*(age - 55)/10*(dm) -
        0.1561543*(age - 55)/10*(smoking) -
        0.1012429*(age - 55)/10*(min(egfr, 60) - 60)/(-15) +
        if(!(is.na(uacr))) {0.1007571*log(adjust(uacr))}
      else if (is.na(uacr)) {(0.0572456)}

      logor_30yr_ASCVD = -1.873449 +
        0.3995607*((age - 55)/10) -
        0.094557*((age - 55)/10) ^ 2 +
        0.1686692*((mmol_conversion(tc) - mmol_conversion(hdl))- 3.5) -
        0.1202145*(mmol_conversion(hdl)- 1.3)/0.3 -
        0.0555561*(min(sbp, 110) - 110)/20 +
        0.2633566*(max(sbp, 110) - 130)/20 +
        0.4362036*(dm) +
        0.1716233*(smoking) -
        0.0775282*(min(egfr, 60) - 60)/(-15) +
        0.0561236*(max(egfr, 60) - 90)/(-15) +
        0.1319331*(bptreat) +
        0.0102428*(statin) -
        0.0269294*(bptreat)*(max(sbp, 110) - 130)/20 +
        0.0920557*(statin)*((mmol_conversion(tc) - mmol_conversion(hdl))- 3.5) -
        0.0297021*(age - 55)/10*((mmol_conversion(tc) - mmol_conversion(hdl))- 3.5) +
        0.0217935*(age - 55)/10*(mmol_conversion(hdl)- 1.3)/0.3 -
        0.0893347*(age - 55)/10*(max(sbp, 110) - 130)/20 -
        0.2081467*(age - 55)/10*(dm) -
        0.1542716*(age - 55)/10*(smoking) -
        0.0597254*(age - 55)/10*(min(egfr, 60) - 60)/(-15) +
        if(!(is.na(uacr))) {0.0684872*log(adjust(uacr))}
      else if (is.na(uacr)) {(0.0193962)}

      logor_30yr_HF = -2.314872 +
        0.5750236*((age - 55)/10) -
        0.1062268*((age - 55)/10) ^ 2 -
        0.4633994*(min(sbp, 110) - 110)/20 +
        0.2742874*(max(sbp, 110) - 130)/20 +
        0.612208*(dm) +
        0.2614987*(smoking) +
        0.0895459*(min(bmi, 30) - 25)/5 +
        0.2632424*(max(bmi, 30) - 30)/5 +
        0.1430472*(min(egfr, 60) - 60)/(-15) +
        0.0535184*(max(egfr, 60) - 90)/(-15) +
        0.2417468*(bptreat) -
        0.0498574*(bptreat)*(max(sbp, 110) - 130)/20 -
        0.1193827*(age - 55)/10*(max(sbp, 110) - 130)/20 -
        0.316651*(age - 55)/10*(dm) -
        0.2046122*(age - 55)/10*(smoking) -
        0.0216878*(age - 55)/10*(max(bmi, 30) - 30)/5 -
        0.1165637*(age - 55)/10*(min(egfr, 60) - 60)/(-15) +
        if(!(is.na(uacr))) {0.1366452*log(adjust(uacr))}
      else if (is.na(uacr)) {(0.1078355)}
    }

    prevent_uacr_10yr_CVD = 100*exp(logor_10yr_CVD) / (1 + exp(logor_10yr_CVD))
    prevent_uacr_30yr_CVD = 100*exp(logor_30yr_CVD) / (1 + exp(logor_30yr_CVD))
    prevent_uacr_10yr_ASCVD = 100*exp(logor_10yr_ASCVD) / (1 + exp(logor_10yr_ASCVD))
    prevent_uacr_30yr_ASCVD = 100*exp(logor_30yr_ASCVD) / (1 + exp(logor_30yr_ASCVD))
    prevent_uacr_10yr_HF = 100*exp(logor_10yr_HF) / (1 + exp(logor_10yr_HF))
    prevent_uacr_30yr_HF = 100*exp(logor_30yr_HF) / (1 + exp(logor_30yr_HF))

  }

  if (!is.na(age)) {
    if(age > 59 & age <= 79) {
      prevent_uacr_30yr_ASCVD = prevent_uacr_30yr_HF = prevent_uacr_30yr_CVD = NA
    } else if (age < 30 | age > 79){
      prevent_uacr_30yr_ASCVD = prevent_uacr_30yr_HF = prevent_uacr_30yr_CVD = prevent_uacr_10yr_ASCVD = prevent_uacr_10yr_HF = prevent_uacr_10yr_CVD = NA
    }
  }

  if (is.na(tc) | tc < 130 | tc > 320) { prevent_uacr_30yr_ASCVD = prevent_uacr_30yr_CVD = prevent_uacr_10yr_ASCVD = prevent_uacr_10yr_CVD = NA
  }

  if (is.na(hdl) | hdl < 20 | hdl > 100) { prevent_uacr_30yr_ASCVD = prevent_uacr_30yr_CVD = prevent_uacr_10yr_ASCVD = prevent_uacr_10yr_CVD = NA
  }

  if (is.na(sbp) | sbp < 90 | sbp > 200) { prevent_uacr_30yr_ASCVD = prevent_uacr_30yr_HF = prevent_uacr_30yr_CVD = prevent_uacr_10yr_ASCVD = prevent_uacr_10yr_HF = prevent_uacr_10yr_CVD = NA
  }

  if(!(all(is.numeric(dm)) & (dm %in% c(0, 1)))) { prevent_uacr_30yr_ASCVD = prevent_uacr_30yr_HF = prevent_uacr_30yr_CVD = prevent_uacr_10yr_ASCVD = prevent_uacr_10yr_HF = prevent_uacr_10yr_CVD = NA
  }

  if(!(all(is.numeric(smoking)) & (smoking %in% c(0, 1)))) { prevent_uacr_30yr_ASCVD = prevent_uacr_30yr_HF = prevent_uacr_30yr_CVD = prevent_uacr_10yr_ASCVD = prevent_uacr_10yr_HF = prevent_uacr_10yr_CVD = NA
  }

  if (is.na(egfr) | egfr <= 0) { prevent_uacr_30yr_ASCVD = prevent_uacr_30yr_HF = prevent_uacr_30yr_CVD = prevent_uacr_10yr_ASCVD = prevent_uacr_10yr_HF = prevent_uacr_10yr_CVD = NA
  }

  if(!(all(is.numeric(bptreat)) & (bptreat %in% c(0, 1)))) { prevent_uacr_30yr_ASCVD = prevent_uacr_30yr_HF = prevent_uacr_30yr_CVD = prevent_uacr_10yr_ASCVD = prevent_uacr_10yr_HF = prevent_uacr_10yr_CVD = NA
  }

  if(!(all(is.numeric(statin)) & (statin %in% c(0, 1)))) { prevent_uacr_30yr_ASCVD = prevent_uacr_30yr_CVD = prevent_uacr_10yr_ASCVD = prevent_uacr_10yr_CVD = NA
  }

  if (is.na(bmi) | bmi < 18.5 | bmi >= 40) { prevent_uacr_30yr_HF = prevent_uacr_10yr_HF = NA
  }

  if (!is.na(uacr) & (uacr < 0)) { prevent_uacr_30yr_ASCVD = prevent_uacr_30yr_HF = prevent_uacr_30yr_CVD = prevent_uacr_10yr_ASCVD = prevent_uacr_10yr_HF = prevent_uacr_10yr_CVD = NA
  }

  prevent_uacr_values <- data.frame(prevent_uacr_10yr_CVD = prevent_uacr_10yr_CVD,
                                    prevent_uacr_10yr_ASCVD = prevent_uacr_10yr_ASCVD,
                                    prevent_uacr_10yr_HF = prevent_uacr_10yr_HF,
                                    prevent_uacr_30yr_CVD = prevent_uacr_30yr_CVD,
                                    prevent_uacr_30yr_ASCVD = prevent_uacr_30yr_ASCVD,
                                    prevent_uacr_30yr_HF = prevent_uacr_30yr_HF)

  return(prevent_uacr_values)
}

#' @name pred_risk_uacr_v
#' @title pred_risk_uacr_v
#' @param sex Sex, numeric.
#' \itemize{
#'     \item 0 = male
#'     \item 1 = female
#'  }
#' @param age Age (30-79 yrs), numeric.
#' @param tc Total cholesterol (130-320 mg/dL), numeric.
#'
#' \emph{Used in the calculation of non-HDL cholesterol for input into equations, where non-HDL = TC - HDL}.
#' @param hdl High density lipoprotein cholesterol (20-100 mg/dL), numeric.
#' @param sbp Systolic blood pressure (90-200 mmHg), numeric.
#' @param dm Diabetes status (0 or 1), numeric.
#' \itemize{
#'     \item 0 = no history of diabetes
#'     \item 1 = any history of diabetes
#' }
#' @param smoking Smoking status (0 or 1), numeric.
#' \itemize{
#'    \item 0 = non-smoking individual
#'    \item 1 = current smoking
#' }
#' @param bmi Body mass index (18.5-39.9 kg/m^2), numeric.
#' @param egfr Estimated glomerular filtration rate (>0 mL/min/1.73m^2), numeric.
#'
#' \emph{Calculated using the 2021 CKD-EPI creatinine equation (Inker et al., 2021)}.
#' @param bptreat Treatment for hypertension (0 or 1), numeric.
#' \itemize{
#'    \item 0 = no treatment
#'    \item 1 = any treatment
#' }
#' @param statin Statin use (0 or 1), numeric.
#' \itemize{
#'    \item 0 = no statin use
#'    \item 1 = any statin use
#' }
#' @param uacr Urine albumin-creatinine ratio (>=0 mg/g), numeric. If uacr = NA,
#' missing coefficient will be used for uacr.
#'
#' @keywords internal

pred_risk_uacr_v <- Vectorize(pred_risk_uacr)

#' @description \strong{prevent_uacr} returns the predicted risks (absolute risk, percent)
#' using the PREVENT base + UACR equation. \cr
#' @details Individuals missing any required input variables (sex, age, sbp, dm, smoking, egfr, bptreat)
#' will return "NA" since these are required variables to calculate risk estimates. Cholesterol variables (tc, hdl, statin)
#' are required for total CVD and ASCVD risk calculations while bmi is required for HF risk
#' calculation; individuals missing these variables will return "NA" only for the calculation of risks
#' requiring the input. For uacr, a missing coefficient is available and may be used when using "prevent_uacr". If risk
#' factor levels are out of range based on how this was defined in the development of the
#' equations (Khan et al., 2024), a risk estimate will not be calculated and the function will return “NA”.
#'
#' @name prevent_uacr
#' @title AHA PREVENT base + UACR equation
#' @param sex Sex, numeric.
#' \itemize{
#'     \item 0 = male
#'     \item 1 = female
#'  }
#' @param age Age (30-79 yrs), numeric.
#' @param tc Total cholesterol (130-320 mg/dL), numeric.
#'
#' \emph{Used in the calculation of non-HDL cholesterol for input into equations, where non-HDL = TC - HDL}.
#' @param hdl High density lipoprotein cholesterol (20-100 mg/dL), numeric.
#' @param sbp Systolic blood pressure (90-200 mmHg), numeric.
#' @param dm Diabetes status (0 or 1), numeric.
#' \itemize{
#'     \item 0 = no history of diabetes
#'     \item 1 = any history of diabetes
#' }
#' @param smoking Smoking status (0 or 1), numeric.
#' \itemize{
#'    \item 0 = non-smoking individual
#'    \item 1 = current smoking
#' }
#' @param bmi Body mass index (18.5-39.9 kg/m^2), numeric.
#' @param egfr Estimated glomerular filtration rate (>0 mL/min/1.73m^2), numeric.
#'
#' \emph{Calculated using the 2021 CKD-EPI creatinine equation (Inker et al., 2021)}.
#' @param bptreat Treatment for hypertension (0 or 1), numeric.
#' \itemize{
#'    \item 0 = no treatment
#'    \item 1 = any treatment
#' }
#' @param statin Statin use (0 or 1), numeric.
#' \itemize{
#'    \item 0 = no statin use
#'    \item 1 = any statin use
#' }
#' @param uacr Urine albumin-creatinine ratio (>=0 mg/g), numeric. If uacr = NA,
#' missing coefficient will be used for uacr.
#'
#' @returns Data frame containing six variables: prevent_uacr_10yr_CVD,
#' prevent_uacr_30yr_CVD, prevent_uacr_10yr_ASCVD,
#' prevent_uacr_30yr_ASCVD, prevent_uacr_10yr_HF, and prevent_uacr_30yr_HF.
#' \itemize{
#'    \item prevent_uacr_10yr_CVD = Predicted 10-year Total CVD risk
#'    \item prevent_uacr_30yr_CVD = Predicted 30-year Total CVD risk
#'    \item prevent_uacr_10yr_ASCVD = Predicted 10-year ASCVD risk
#'    \item prevent_uacr_30yr_ASCVD = Predicted 30-year ASCVD risk
#'    \item prevent_uacr_10yr_HF = Predicted 10-year HF risk
#'    \item prevent_uacr_30yr_HF = Predicted 30-year HF risk
#' }
#'
#' @export
#'
#' @examples
#' ## Calculate predicted risks for a 45-year-old woman with a TC of 200 mg/dL
#' ## and HDL-C of 60 mg/dL (not on statin therapy), a systolic blood pressure of
#' ## 120 mm Hg (not on anti-hypertensive treatment), has diabetes, does not smoke,
#' ## with a BMI of 25 kg/m^2, eGFR of 95 mL/min/1.73m^2, and UACR of 10 mg/g.
#' \donttest{
#'   prevent_uacr(sex = 1, age = 45, tc = 200, hdl = 60, sbp = 120, dm = 1,
#'   smoking = 0, bmi = 25, egfr = 95, bptreat = 0, statin = 0, uacr = 10)
#' }
#' ## Calculate predicted 10-year risks only for 75-year old man
#' ## (no 30-year risks calculated due to age > 75).
#' \donttest{
#'   prevent_uacr(sex = 0, age = 75, tc = 250, hdl = 90, sbp = 130, dm = 0,
#'   smoking = 1, bmi = 30, egfr = 105, bptreat = 0, statin = 1, uacr = 50)
#' }
#' ## Calculate predicted total CVD and ASCVD risks only for 39-year old woman
#' ## (no HF risks calculated due to missing BMI).
#' \donttest{
#'   prevent_uacr(sex = 1, age = 39, tc = 190, hdl = 50, sbp = 110, dm = 0,
#'   smoking = 0, bmi = NA, egfr = 120, bptreat = 0, statin = 0, uacr = 5)
#' }
#' ## Calculate predicted HF risks only for 58-year old man
#' ## (no CVD/ASCVD risks calculated due to missing cholesterol/statin variables).
#' \donttest{
#'   prevent_uacr(sex = 0, age = 58, tc = 230, hdl = NA, sbp = 150, dm = 0,
#'   smoking = 0, bmi = 35, egfr = 45, bptreat = 1, statin = NA, uacr = 150)
#' }
#' ## Calculate predicted risks for an existing data frame called "yourdata" and
#' ## append generated risk scores to original data frame.
#' \donttest{
#'   yourdata <- data.frame(sex = c(1, 0, 1, 0),
#'                        age = c(45, 75, 39, 58),
#'                        tc = c(200, 240, 190, 267),
#'                        hdl = c(60, 90, 50, NA),
#'                        sbp = c(120, 130, 110, 150),
#'                        dm  = c(0, 0, 1, 0),
#'                        smoking = c(1, 0, 0, 0),
#'                        bmi = c(25, 30, NA, 35),
#'                        egfr = c(95, 105, 120, 45),
#'                        bptreat = c(0, 1, 0, 1),
#'                        statin = c(0, 1, 0, NA),
#'                        uacr = c(150, 10, 500, 45))
#'
#'   riskscores <- prevent_uacr(yourdata$sex, yourdata$age, yourdata$tc, yourdata$hdl,
#'                yourdata$sbp, yourdata$dm, yourdata$smoking, yourdata$bmi,
#'                yourdata$egfr, yourdata$bptreat, yourdata$statin,
#'                yourdata$uacr)
#'
#'   yourdata_riskscores <- cbind(yourdata, riskscores)
#'
#'   print(yourdata_riskscores)
#' }
#'

prevent_uacr <- function(sex, age, tc, hdl, sbp, dm, smoking, bmi, egfr, bptreat, statin, uacr){
  temp_uacr <- as.data.frame(t(pred_risk_uacr_v(sex, age, tc, hdl, sbp, dm, smoking, bmi, egfr, bptreat, statin, uacr)))
  names(temp_uacr) <- c("prevent_uacr_10yr_CVD",
                        "prevent_uacr_10yr_ASCVD",
                        "prevent_uacr_10yr_HF",
                        "prevent_uacr_30yr_CVD",
                        "prevent_uacr_30yr_ASCVD",
                        "prevent_uacr_30yr_HF")
  return(temp_uacr)
}

#' @name pred_risk_hba1c
#' @title pred_risk_hba1c
#' @param sex Sex, numeric.
#' \itemize{
#'     \item 0 = male
#'     \item 1 = female
#'  }
#' @param age Age (30-79 yrs), numeric.
#' @param tc Total cholesterol (130-320 mg/dL), numeric.
#'
#' \emph{Used in the calculation of non-HDL cholesterol for input into equations, where non-HDL = TC - HDL}.
#' @param hdl High density lipoprotein cholesterol (20-100 mg/dL), numeric.
#' @param sbp Systolic blood pressure (90-200 mmHg), numeric.
#' @param dm Diabetes status (0 or 1), numeric.
#' \itemize{
#'     \item 0 = no history of diabetes
#'     \item 1 = any history of diabetes
#' }
#' @param smoking Smoking status (0 or 1), numeric.
#' \itemize{
#'    \item 0 = non-smoking individual
#'    \item 1 = current smoking
#' }
#' @param bmi Body mass index (18.5-39.9 kg/m^2), numeric.
#' @param egfr Estimated glomerular filtration rate (>0 mL/min/1.73m^2), numeric.
#'
#' \emph{Calculated using the 2021 CKD-EPI creatinine equation (Inker et al., 2021)}.
#' @param bptreat Treatment for hypertension (0 or 1), numeric.
#' \itemize{
#'    \item 0 = no treatment
#'    \item 1 = any treatment
#' }
#' @param statin Statin use (0 or 1), numeric.
#' \itemize{
#'    \item 0 = no statin use
#'    \item 1 = any statin use
#' }
#' @param hba1c Hemoglobin A1c (>0 percent), numeric. If hba1c = NA,
#' missing coefficient will be used for hba1c.
#'
#' @keywords internal

pred_risk_hba1c <- function(sex, age, tc, hdl, sbp, dm, smoking, bmi, egfr, bptreat, statin, hba1c) {

  if(!all(is.numeric(sex) & (sex %in% c(0, 1)))) {
    prevent_hba1c_30yr_ASCVD = prevent_hba1c_30yr_HF = prevent_hba1c_30yr_CVD = prevent_hba1c_10yr_ASCVD = prevent_hba1c_10yr_HF = prevent_hba1c_10yr_CVD = NA
  } else {
    if(sex==1) {
      logor_10yr_CVD = -3.306162 +
        0.7858178*((age - 55)/10) +
        0.0194438*((mmol_conversion(tc) - mmol_conversion(hdl)) - 3.5) -
        0.1521964*(mmol_conversion(hdl) - 1.3)/0.3 -
        0.2296681*(min(sbp, 110) - 110)/20 +
        0.3465777*(max(sbp, 110) - 130)/20 +
        0.5366241*(dm) +
        0.5411682*(smoking) +
        0.5931898*(min(egfr, 60) - 60)/(-15) +
        0.0472458*(max(egfr, 60) - 90)/(-15) +
        0.3158567*(bptreat) -
        0.1535174*(statin) -
        0.0687752*(bptreat)*(max(sbp, 110) - 130)/20 +
        0.1054746*(statin)*((mmol_conversion(tc) - mmol_conversion(hdl)) - 3.5) -
        0.0761119*(age - 55)/10*((mmol_conversion(tc) - mmol_conversion(hdl)) - 3.5) +
        0.0307469*(age - 55)/10*(mmol_conversion(hdl) - 1.3)/0.3 -
        0.0905966*(age - 55)/10*(max(sbp, 110) - 130)/20 -
        0.2241857*(age - 55)/10*(dm) -
        0.080186*(age - 55)/10*(smoking) -
        0.1667286*(age - 55)/10*(min(egfr, 60) - 60)/(-15) +
        if(!(is.na(hba1c))) {0.1338348*(hba1c-5.3)*(1-dm) +
            0.1622409*(hba1c-5.3)*(dm)}
      else if (is.na(hba1c)) {(-0.0142496)}

      logor_10yr_ASCVD = -3.838746 +
        0.7111831*((age - 55)/10) +
        0.106797*((mmol_conversion(tc) - mmol_conversion(hdl)) - 3.5) -
        0.1425745*(mmol_conversion(hdl) - 1.3)/0.3 -
        0.0736824*(min(sbp, 110) - 110)/20 +
        0.3480844*(max(sbp, 110) - 130)/20 +
        0.5112951*(dm) +
        0.4880292*(smoking) +
        0.4754997*(min(egfr, 60) - 60)/(-15) +
        0.0438132*(max(egfr, 60) - 90)/(-15) +
        0.2259093*(bptreat) -
        0.0648872*(statin) -
        0.0437645*(bptreat)*(max(sbp, 110) - 130)/20 +
        0.0697082*(statin)*((mmol_conversion(tc) - mmol_conversion(hdl)) - 3.5) -
        0.0506382*(age - 55)/10*((mmol_conversion(tc) - mmol_conversion(hdl)) - 3.5) +
        0.0327475*(age - 55)/10*(mmol_conversion(hdl) - 1.3)/0.3 -
        0.0996442*(age - 55)/10*(max(sbp, 110) - 130)/20 -
        0.1924338*(age - 55)/10*(dm) -
        0.0803539*(age - 55)/10*(smoking) -
        0.1682586*(age - 55)/10*(min(egfr, 60) - 60)/(-15) +
        if(!(is.na(hba1c))) {0.1339055*(hba1c-5.3)*(1-dm) +
            0.1596461*(hba1c-5.3)*(dm)}
      else if (is.na(hba1c)) {(0.0015678)}

      logor_10yr_HF = -4.288225 +
        0.8997391*((age - 55)/10) -
        0.4422749*(min(sbp, 110) - 110)/20 +
        0.3378691*(max(sbp, 110) - 130)/20 +
        0.681284*(dm) +
        0.5886005*(smoking) -
        0.0148657*(min(bmi, 30) - 25)/5 +
        0.2958374*(max(bmi, 30) - 30)/5 +
        0.73447*(min(egfr, 60) - 60)/(-15) +
        0.05926*(max(egfr, 60) - 90)/(-15) +
        0.3543475*(bptreat) -
        0.1002139*(bptreat)*(max(sbp, 110) - 130)/20 -
        0.0878765*(age - 55)/10*(max(sbp, 110) - 130)/20 -
        0.303684*(age - 55)/10*(dm) -
        0.1178943*(age - 55)/10*(smoking) -
        0.008345*(age - 55)/10*(max(bmi, 30) - 30)/5 -
        0.1912183*(age - 55)/10*(min(egfr, 60) - 60)/(-15) +
        if(!(is.na(hba1c))) {0.1856442*(hba1c-5.3)*(1-dm) +
            0.1833083*(hba1c-5.3)*(dm)}
      else if (is.na(hba1c)) {(-0.0143112)}

      logor_30yr_CVD = -1.341059 +
        0.5343493*((age - 55)/10) -
        0.0952314*((age - 55)/10) ^ 2 +
        0.0298124*((mmol_conversion(tc) - mmol_conversion(hdl))- 3.5) -
        0.1578451*(mmol_conversion(hdl)- 1.3)/0.3 -
        0.1504488*(min(sbp, 110) - 110)/20 +
        0.3173368*(max(sbp, 110) - 130)/20 +
        0.4314738*(dm) +
        0.3209399*(smoking) +
        0.1771435*(min(egfr, 60) - 60)/(-15) +
        0.0582828*(max(egfr, 60) - 90)/(-15) +
        0.2888947*(bptreat) -
        0.0795886*(statin) -
        0.0600438*(bptreat)*(max(sbp, 110) - 130)/20 +
        0.0920598*(statin)*((mmol_conversion(tc) - mmol_conversion(hdl))- 3.5) -
        0.0696108*(age - 55)/10*((mmol_conversion(tc) - mmol_conversion(hdl))- 3.5) +
        0.0308807*(age - 55)/10*(mmol_conversion(hdl)- 1.3)/0.3 -
        0.0954051*(age - 55)/10*(max(sbp, 110) - 130)/20 -
        0.2763408*(age - 55)/10*(dm) -
        0.1623944*(age - 55)/10*(smoking) -
        0.1430514*(age - 55)/10*(min(egfr, 60) - 60)/(-15) +
        if(!(is.na(hba1c))) {0.0940543*(hba1c-5.3)*(1-dm) +
            0.1116486*(hba1c-5.3)*(dm)}
      else if (is.na(hba1c)) {(-0.0024798)}

      logor_30yr_ASCVD = -2.011533 +
        0.4555574*((age - 55)/10) -
        0.0903501*((age - 55)/10) ^ 2 +
        0.1148321*((mmol_conversion(tc) - mmol_conversion(hdl))- 3.5) -
        0.1458754*(mmol_conversion(hdl)- 1.3)/0.3 +
        0.0089323*(min(sbp, 110) - 110)/20 +
        0.3139029*(max(sbp, 110) - 130)/20 +
        0.386281*(dm) +
        0.2714309*(smoking) +
        0.0930987*(min(egfr, 60) - 60)/(-15) +
        0.0532216*(max(egfr, 60) - 90)/(-15) +
        0.1862181*(bptreat) +
        0.0106964*(statin) -
        0.0329713*(bptreat)*(max(sbp, 110) - 130)/20 +
        0.0583609*(statin)*((mmol_conversion(tc) - mmol_conversion(hdl))- 3.5) -
        0.0463273*(age - 55)/10*((mmol_conversion(tc) - mmol_conversion(hdl))- 3.5) +
        0.0324717*(age - 55)/10*(mmol_conversion(hdl)- 1.3)/0.3 -
        0.1004777*(age - 55)/10*(max(sbp, 110) - 130)/20 -
        0.2266944*(age - 55)/10*(dm) -
        0.1541859*(age - 55)/10*(smoking) -
        0.1286005*(age - 55)/10*(min(egfr, 60) - 60)/(-15) +
        if(!(is.na(hba1c))) {0.0875827*(hba1c-5.3)*(1-dm) +
            0.1126417*(hba1c-5.3)*(dm)}
      else if (is.na(hba1c)) {(0.0124356)}

      logor_30yr_HF = -2.193553 +
        0.6210856*((age - 55)/10) -
        0.1000972*((age - 55)/10) ^ 2 -
        0.3773697*(min(sbp, 110) - 110)/20 +
        0.295316*(max(sbp, 110) - 130)/20 +
        0.5681692*(dm) +
        0.3449139*(smoking) +
        0.0540094*(min(bmi, 30) - 25)/5 +
        0.249767*(max(bmi, 30) - 30)/5 +
        0.2875781*(min(egfr, 60) - 60)/(-15) +
        0.0692013*(max(egfr, 60) - 90)/(-15) +
        0.3334936*(bptreat) -
        0.0922339*(bptreat)*(max(sbp, 110) - 130)/20 -
        0.0907885*(age - 55)/10*(max(sbp, 110) - 130)/20 -
        0.3554646*(age - 55)/10*(dm) -
        0.2008846*(age - 55)/10*(smoking) -
        0.0079611*(age - 55)/10*(max(bmi, 30) - 30)/5 -
        0.156803*(age - 55)/10*(min(egfr, 60) - 60)/(-15) +
        if(!(is.na(hba1c))) {0.1448336*(hba1c-5.3)*(1-dm) +
            0.1277838*(hba1c-5.3)*(dm)}
      else if (is.na(hba1c)) {(-0.0022589)}
    }
    else {
      logor_10yr_CVD =  -3.040901 +
        0.7699177*((age - 55)/10) +
        0.0605093*((mmol_conversion(tc) - mmol_conversion(hdl)) - 3.5) -
        0.0888525*(mmol_conversion(hdl) - 1.3)/0.3 -
        0.417713*(min(sbp, 110) - 110)/20 +
        0.3288657*(max(sbp, 110) - 130)/20 +
        0.4759471*(dm) +
        0.4385663*(smoking) +
        0.5334616*(min(egfr, 60) - 60)/(-15) +
        0.0206431*(max(egfr, 60) - 90)/(-15) +
        0.2917524*(bptreat) -
        0.1383313*(statin) -
        0.0482622*(bptreat)*(max(sbp, 110) - 130)/20 +
        0.1393796*(statin)*((mmol_conversion(tc) - mmol_conversion(hdl)) - 3.5) -
        0.0463501*(age - 55)/10*((mmol_conversion(tc) - mmol_conversion(hdl)) - 3.5) +
        0.0205926*(age - 55)/10*(mmol_conversion(hdl) - 1.3)/0.3 -
        0.1037717*(age - 55)/10*(max(sbp, 110) - 130)/20 -
        0.1737697*(age - 55)/10*(dm) -
        0.0915839*(age - 55)/10*(smoking) -
        0.1637039*(age - 55)/10*(min(egfr, 60) - 60)/(-15) +
        if(!(is.na(hba1c))) {0.13159*(hba1c-5.3)*(1-dm) +
            0.1295185*(hba1c-5.3)*(dm)}
      else if (is.na(hba1c)) {(-0.0128373)}

      logor_10yr_ASCVD = -3.51835 +
        0.7064146*((age - 55)/10) +
        0.1532267*((mmol_conversion(tc) - mmol_conversion(hdl)) - 3.5) -
        0.1082166*(mmol_conversion(hdl) - 1.3)/0.3 -
        0.2675288*(min(sbp, 110) - 110)/20 +
        0.3173809*(max(sbp, 110) - 130)/20 +
        0.432604*(dm) +
        0.3958842*(smoking) +
        0.3665014*(min(egfr, 60) - 60)/(-15) +
        0.0250243*(max(egfr, 60) - 90)/(-15) +
        0.2061158*(bptreat) -
        0.0899988*(statin) -
        0.0334959*(bptreat)*(max(sbp, 110) - 130)/20 +
        0.1034168*(statin)*((mmol_conversion(tc) - mmol_conversion(hdl)) - 3.5) -
        0.0255406*(age - 55)/10*((mmol_conversion(tc) - mmol_conversion(hdl)) - 3.5) +
        0.0247538*(age - 55)/10*(mmol_conversion(hdl) - 1.3)/0.3 -
        0.0917441*(age - 55)/10*(max(sbp, 110) - 130)/20 -
        0.1499195*(age - 55)/10*(dm) -
        0.098089*(age - 55)/10*(smoking) -
        0.1305231*(age - 55)/10*(min(egfr, 60) - 60)/(-15) +
        if(!(is.na(hba1c))) {0.1157161*(hba1c-5.3)*(1-dm) +
            0.1288303*(hba1c-5.3)*(dm)}
      else if (is.na(hba1c)) {(-0.0010001)}

      logor_10yr_HF = -3.961954 +
        0.911787*((age - 55)/10) -
        0.6568071*(min(sbp, 110) - 110)/20 +
        0.3524645*(max(sbp, 110) - 130)/20 +
        0.5849752*(dm) +
        0.5014014*(smoking) -
        0.0512352*(min(bmi, 30) - 25)/5 +
        0.365294*(max(bmi, 30) - 30)/5 +
        0.6892219*(min(egfr, 60) - 60)/(-15) +
        0.0292377*(max(egfr, 60) - 90)/(-15) +
        0.3038296*(bptreat) -
        0.0515032*(bptreat)*(max(sbp, 110) - 130)/20 -
        0.1262343*(age - 55)/10*(max(sbp, 110) - 130)/20 -
        0.2449514*(age - 55)/10*(dm) -
        0.1392217*(age - 55)/10*(smoking) +
        0.0009592*(age - 55)/10*(max(bmi, 30) - 30)/5 -
        0.1917105*(age - 55)/10*(min(egfr, 60) - 60)/(-15) +
        if(!(is.na(hba1c))) {0.1652857*(hba1c-5.3)*(1-dm) +
            0.1505859*(hba1c-5.3)*(dm)}
      else if (is.na(hba1c)) {(-0.0113444)}

      logor_30yr_CVD = -1.180767 +
        0.4519873*((age - 55)/10) -
        0.101624*((age - 55)/10) ^ 2 +
        0.0700456*((mmol_conversion(tc) - mmol_conversion(hdl))- 3.5) -
        0.0968005*(mmol_conversion(hdl)- 1.3)/0.3 -
        0.1923527*(min(sbp, 110) - 110)/20 +
        0.2827043*(max(sbp, 110) - 130)/20 +
        0.3417152*(dm) +
        0.2105272*(smoking) +
        0.1113291*(min(egfr, 60) - 60)/(-15) +
        0.0640135*(max(egfr, 60) - 90)/(-15) +
        0.2334248*(bptreat) -
        0.0299421*(statin) -
        0.0393204*(bptreat)*(max(sbp, 110) - 130)/20 +
        0.1228854*(statin)*((mmol_conversion(tc) - mmol_conversion(hdl))- 3.5) -
        0.0463737*(age - 55)/10*((mmol_conversion(tc) - mmol_conversion(hdl))- 3.5) +
        0.0184599*(age - 55)/10*(mmol_conversion(hdl)- 1.3)/0.3 -
        0.1085744*(age - 55)/10*(max(sbp, 110) - 130)/20 -
        0.2208049*(age - 55)/10*(dm) -
        0.1577978*(age - 55)/10*(smoking) -
        0.1179375*(age - 55)/10*(min(egfr, 60) - 60)/(-15) +
        if(!(is.na(hba1c))) {0.0768169*(hba1c-5.3)*(1-dm) +
            0.0777295*(hba1c-5.3)*(dm)}
      else if (is.na(hba1c)) {(0.0092204)}

      logor_30yr_ASCVD = -1.777708 +
        0.3883267*((age - 55)/10) -
        0.0958114*((age - 55)/10) ^ 2 +
        0.1613374*((mmol_conversion(tc) - mmol_conversion(hdl))- 3.5) -
        0.1144418*(mmol_conversion(hdl)- 1.3)/0.3 -
        0.0474338*(min(sbp, 110) - 110)/20 +
        0.2691281*(max(sbp, 110) - 130)/20 +
        0.2859773*(dm) +
        0.1759553*(smoking) -
        0.0242898*(min(egfr, 60) - 60)/(-15) +
        0.0644523*(max(egfr, 60) - 90)/(-15) +
        0.142874*(bptreat) +
        0.0115062*(statin) -
        0.02333*(bptreat)*(max(sbp, 110) - 130)/20 +
        0.0899664*(statin)*((mmol_conversion(tc) - mmol_conversion(hdl))- 3.5) -
        0.0275478*(age - 55)/10*((mmol_conversion(tc) - mmol_conversion(hdl))- 3.5) +
        0.022573*(age - 55)/10*(mmol_conversion(hdl)- 1.3)/0.3 -
        0.090802*(age - 55)/10*(max(sbp, 110) - 130)/20 -
        0.1771894*(age - 55)/10*(dm) -
        0.1548847*(age - 55)/10*(smoking) -
        0.0732754*(age - 55)/10*(min(egfr, 60) - 60)/(-15) +
        if(!(is.na(hba1c))) {0.0591089*(hba1c-5.3)*(1-dm) +
            0.0821158*(hba1c-5.3)*(dm)}
      else if (is.na(hba1c)) {(0.0179755)}

      logor_30yr_HF = -1.974999 +
        0.5703729*((age - 55)/10) -
        0.1084544*((age - 55)/10) ^ 2 -
        0.4471767*(min(sbp, 110) - 110)/20 +
        0.2910152*(max(sbp, 110) - 130)/20 +
        0.4507242*(dm) +
        0.259585*(smoking) +
        0.0850676*(min(bmi, 30) - 25)/5 +
        0.2637222*(max(bmi, 30) - 30)/5 +
        0.2454706*(min(egfr, 60) - 60)/(-15) +
        0.0675649*(max(egfr, 60) - 90)/(-15) +
        0.2611991*(bptreat) -
        0.0408908*(bptreat)*(max(sbp, 110) - 130)/20 -
        0.1241051*(age - 55)/10*(max(sbp, 110) - 130)/20 -
        0.2849461*(age - 55)/10*(dm) -
        0.2032308*(age - 55)/10*(smoking) -
        0.0239714*(age - 55)/10*(max(bmi, 30) - 30)/5 -
        0.138301*(age - 55)/10*(min(egfr, 60) - 60)/(-15) +
        if(!(is.na(hba1c))) {0.1101184*(hba1c-5.3)*(1-dm) +
            0.0949198*(hba1c-5.3)*(dm)}
      else if (is.na(hba1c)) {(0.0084192)}
    }

    prevent_hba1c_10yr_CVD = 100*exp(logor_10yr_CVD) / (1 + exp(logor_10yr_CVD))
    prevent_hba1c_30yr_CVD = 100*exp(logor_30yr_CVD) / (1 + exp(logor_30yr_CVD))
    prevent_hba1c_10yr_ASCVD = 100*exp(logor_10yr_ASCVD) / (1 + exp(logor_10yr_ASCVD))
    prevent_hba1c_30yr_ASCVD = 100*exp(logor_30yr_ASCVD) / (1 + exp(logor_30yr_ASCVD))
    prevent_hba1c_10yr_HF = 100*exp(logor_10yr_HF) / (1 + exp(logor_10yr_HF))
    prevent_hba1c_30yr_HF = 100*exp(logor_30yr_HF) / (1 + exp(logor_30yr_HF))

  }

  if (!is.na(age)) {
    if(age > 59 & age <= 79) {
      prevent_hba1c_30yr_ASCVD = prevent_hba1c_30yr_HF = prevent_hba1c_30yr_CVD = NA
    } else if (age < 30 | age > 79){
      prevent_hba1c_30yr_ASCVD = prevent_hba1c_30yr_HF = prevent_hba1c_30yr_CVD = prevent_hba1c_10yr_ASCVD = prevent_hba1c_10yr_HF = prevent_hba1c_10yr_CVD = NA
    }
  }

  if (is.na(tc) | tc < 130 | tc > 320) { prevent_hba1c_30yr_ASCVD = prevent_hba1c_30yr_CVD = prevent_hba1c_10yr_ASCVD = prevent_hba1c_10yr_CVD = NA
  }

  if (is.na(hdl) | hdl < 20 | hdl > 100) { prevent_hba1c_30yr_ASCVD = prevent_hba1c_30yr_CVD = prevent_hba1c_10yr_ASCVD = prevent_hba1c_10yr_CVD = NA
  }

  if (is.na(sbp) | sbp < 90 | sbp > 200) { prevent_hba1c_30yr_ASCVD = prevent_hba1c_30yr_HF = prevent_hba1c_30yr_CVD = prevent_hba1c_10yr_ASCVD = prevent_hba1c_10yr_HF = prevent_hba1c_10yr_CVD = NA
  }

  if(!(all(is.numeric(dm)) & (dm %in% c(0, 1)))) { prevent_hba1c_30yr_ASCVD = prevent_hba1c_30yr_HF = prevent_hba1c_30yr_CVD = prevent_hba1c_10yr_ASCVD = prevent_hba1c_10yr_HF = prevent_hba1c_10yr_CVD = NA
  }

  if(!(all(is.numeric(smoking)) & (smoking %in% c(0, 1)))) { prevent_hba1c_30yr_ASCVD = prevent_hba1c_30yr_HF = prevent_hba1c_30yr_CVD = prevent_hba1c_10yr_ASCVD = prevent_hba1c_10yr_HF = prevent_hba1c_10yr_CVD = NA
  }

  if (is.na(egfr) | egfr <= 0) { prevent_hba1c_30yr_ASCVD = prevent_hba1c_30yr_HF = prevent_hba1c_30yr_CVD = prevent_hba1c_10yr_ASCVD = prevent_hba1c_10yr_HF = prevent_hba1c_10yr_CVD = NA
  }

  if(!(all(is.numeric(bptreat)) & (bptreat %in% c(0, 1)))) { prevent_hba1c_30yr_ASCVD = prevent_hba1c_30yr_HF = prevent_hba1c_30yr_CVD = prevent_hba1c_10yr_ASCVD = prevent_hba1c_10yr_HF = prevent_hba1c_10yr_CVD = NA
  }

  if(!(all(is.numeric(statin)) & (statin %in% c(0, 1)))) { prevent_hba1c_30yr_ASCVD = prevent_hba1c_30yr_CVD = prevent_hba1c_10yr_ASCVD = prevent_hba1c_10yr_CVD = NA
  }

  if (is.na(bmi) | bmi < 18.5 | bmi >= 40) { prevent_hba1c_30yr_HF = prevent_hba1c_10yr_HF = NA
  }

  if (!is.na(hba1c) & (hba1c <= 0)) { prevent_hba1c_30yr_ASCVD = prevent_hba1c_30yr_HF = prevent_hba1c_30yr_CVD = prevent_hba1c_10yr_ASCVD = prevent_hba1c_10yr_HF = prevent_hba1c_10yr_CVD = NA
  }

  prevent_hba1c_values <- data.frame(prevent_hba1c_10yr_CVD = prevent_hba1c_10yr_CVD,
                                     prevent_hba1c_10yr_ASCVD = prevent_hba1c_10yr_ASCVD,
                                     prevent_hba1c_10yr_HF = prevent_hba1c_10yr_HF,
                                     prevent_hba1c_30yr_CVD = prevent_hba1c_30yr_CVD,
                                     prevent_hba1c_30yr_ASCVD = prevent_hba1c_30yr_ASCVD,
                                     prevent_hba1c_30yr_HF = prevent_hba1c_30yr_HF)

  return(prevent_hba1c_values)
}

#' @name pred_risk_hba1c_v
#' @title pred_risk_hba1c_v
#' @param sex Sex, numeric.
#' \itemize{
#'     \item 0 = male
#'     \item 1 = female
#'  }
#' @param age Age (30-79 yrs), numeric.
#' @param tc Total cholesterol (130-320 mg/dL), numeric.
#'
#' \emph{Used in the calculation of non-HDL cholesterol for input into equations, where non-HDL = TC - HDL}.
#' @param hdl High density lipoprotein cholesterol (20-100 mg/dL), numeric.
#' @param sbp Systolic blood pressure (90-200 mmHg), numeric.
#' @param dm Diabetes status (0 or 1), numeric.
#' \itemize{
#'     \item 0 = no history of diabetes
#'     \item 1 = any history of diabetes
#' }
#' @param smoking Smoking status (0 or 1), numeric.
#' \itemize{
#'    \item 0 = non-smoking individual
#'    \item 1 = current smoking
#' }
#' @param bmi Body mass index (18.5-39.9 kg/m^2), numeric.
#' @param egfr Estimated glomerular filtration rate (>0 mL/min/1.73m^2), numeric.
#'
#' \emph{Calculated using the 2021 CKD-EPI creatinine equation (Inker et al., 2021)}.
#' @param bptreat Treatment for hypertension (0 or 1), numeric.
#' \itemize{
#'    \item 0 = no treatment
#'    \item 1 = any treatment
#' }
#' @param statin Statin use (0 or 1), numeric.
#' \itemize{
#'    \item 0 = no statin use
#'    \item 1 = any statin use
#' }
#' @param hba1c Hemoglobin A1c (>0 percent), numeric. If hba1c = NA,
#' missing coefficient will be used for hba1c.
#' @keywords internal

pred_risk_hba1c_v <- Vectorize(pred_risk_hba1c)

#' @description \strong{prevent_hba1c} returns the predicted risks (absolute risk, percent)
#' using the PREVENT base + HbA1c equation. \cr
#' @details Individuals missing any required input variables (sex, age, sbp, dm, smoking, egfr, bptreat)
#' will return "NA" since these are required variables to calculate risk estimates. Cholesterol variables (tc, hdl, statin)
#' are required for total CVD and ASCVD risk calculations while bmi is required for HF risk
#' calculation; individuals missing these variables will return "NA" only for the calculation of risks
#' requiring the input. For hba1c, a missing coefficient is available and may be used when using "prevent_hba1c". If risk
#' factor levels are out of range based on how this was defined in the development of the
#' equations (Khan et al., 2024), a risk estimate will not be calculated and the function will return “NA”.
#'
#' @name prevent_hba1c
#' @title AHA PREVENT base + HbA1c equation
#' @param sex Sex, numeric.
#' \itemize{
#'     \item 0 = male
#'     \item 1 = female
#'  }
#' @param age Age (30-79 yrs), numeric.
#' @param tc Total cholesterol (130-320 mg/dL), numeric.
#'
#' \emph{Used in the calculation of non-HDL cholesterol for input into equations, where non-HDL = TC - HDL}.
#' @param hdl High density lipoprotein cholesterol (20-100 mg/dL), numeric.
#' @param sbp Systolic blood pressure (90-200 mmHg), numeric.
#' @param dm Diabetes status (0 or 1), numeric.
#' \itemize{
#'     \item 0 = no history of diabetes
#'     \item 1 = any history of diabetes
#' }
#' @param smoking Smoking status (0 or 1), numeric.
#' \itemize{
#'    \item 0 = non-smoking individual
#'    \item 1 = current smoking
#' }
#' @param bmi Body mass index (18.5-39.9 kg/m^2), numeric.
#' @param egfr Estimated glomerular filtration rate (>0 mL/min/1.73m^2), numeric.
#'
#' \emph{Calculated using the 2021 CKD-EPI creatinine equation (Inker et al., 2021)}.
#' @param bptreat Treatment for hypertension (0 or 1), numeric.
#' \itemize{
#'    \item 0 = no treatment
#'    \item 1 = any treatment
#' }
#' @param statin Statin use (0 or 1), numeric.
#' \itemize{
#'    \item 0 = no statin use
#'    \item 1 = any statin use
#' }
#' @param hba1c Hemoglobin A1c (>0 percent), numeric. If hba1c = NA,
#' missing coefficient will be used for hba1c.
#'
#' @returns Data frame containing six variables: prevent_hba1c_10yr_CVD,
#' prevent_hba1c_30yr_CVD, prevent_hba1c_10yr_ASCVD,
#' prevent_hba1c_30yr_ASCVD, prevent_hba1c_10yr_HF, and prevent_hba1c_30yr_HF.
#' \itemize{
#'    \item prevent_hba1c_10yr_CVD = Predicted 10-year Total CVD risk
#'    \item prevent_hba1c_30yr_CVD = Predicted 30-year Total CVD risk
#'    \item prevent_hba1c_10yr_ASCVD = Predicted 10-year ASCVD risk
#'    \item prevent_hba1c_30yr_ASCVD = Predicted 30-year ASCVD risk
#'    \item prevent_hba1c_10yr_HF = Predicted 10-year HF risk
#'    \item prevent_hba1c_30yr_HF = Predicted 30-year HF risk
#' }
#'
#' @export
#'
#' @examples
#' ## Calculate predicted risks for a 45-year-old woman with a TC of 200 mg/dL
#' ## and HDL-C of 60 mg/dL (not on statin therapy), a systolic blood pressure of
#' ## 120 mm Hg (not on anti-hypertensive treatment), has diabetes, does not smoke,
#' ## with a BMI of 25 kg/m^2, eGFR of 95 mL/min/1.73m^2, and HbA1c of 9%.
#' \donttest{
#'   prevent_hba1c(sex = 1, age = 45, tc = 200, hdl = 60, sbp = 120, dm = 1,
#'   smoking = 0, bmi = 25, egfr = 95, bptreat = 0, statin = 0, hba1c = 9)
#' }
#' ## Calculate predicted 10-year risks only for 75-year old man
#' ## (no 30-year risks calculated due to age > 75).
#' \donttest{
#'   prevent_hba1c(sex = 0, age = 75, tc = 250, hdl = 90, sbp = 130, dm = 0,
#'   smoking = 1, bmi = 30, egfr = 105, bptreat = 0, statin = 1, hba1c = 5.7)
#' }
#' ## Calculate predicted total CVD and ASCVD risks only for 39-year old woman
#' ## (no HF risks calculated due to missing BMI).
#' \donttest{
#'   prevent_hba1c(sex = 1, age = 39, tc = 190, hdl = 50, sbp = 110, dm = 1,
#'   smoking = 0, bmi = NA, egfr = 120, bptreat = 0, statin = 0, hba1c = 13)
#' }
#' ## Calculate predicted HF risks only for 58-year old man
#' ## (no CVD/ASCVD risks calculated due to missing cholesterol/statin variables).
#' \donttest{
#'   prevent_hba1c(sex = 0, age = 58, tc = 230, hdl = NA, sbp = 150, dm = 0,
#'   smoking = 0, bmi = 35, egfr = 45, bptreat = 1, statin = NA, hba1c = 4)
#' }
#' ## Calculate predicted risks for an existing data frame called "yourdata" and
#' ## append generated risk scores to original data frame.
#' \donttest{
#'   yourdata <- data.frame(sex = c(1, 0, 1, 0),
#'                        age = c(45, 75, 39, 58),
#'                        tc = c(200, 240, 190, 267),
#'                        hdl = c(60, 90, 50, NA),
#'                        sbp = c(120, 130, 110, 150),
#'                        dm  = c(0, 0, 1, 0),
#'                        smoking = c(1, 0, 0, 0),
#'                        bmi = c(25, 30, NA, 35),
#'                        egfr = c(95, 105, 120, 45),
#'                        bptreat = c(0, 1, 0, 1),
#'                        statin = c(0, 1, 0, NA),
#'                        hba1c = c(8.5, 4, 6, 10.5))
#'
#'   riskscores <- prevent_hba1c(yourdata$sex, yourdata$age, yourdata$tc, yourdata$hdl,
#'                yourdata$sbp, yourdata$dm, yourdata$smoking, yourdata$bmi,
#'                yourdata$egfr, yourdata$bptreat, yourdata$statin,
#'                yourdata$hba1c)
#'
#'   yourdata_riskscores <- cbind(yourdata, riskscores)
#'
#'   print(yourdata_riskscores)
#' }
#'

prevent_hba1c <- function(sex, age, tc, hdl, sbp, dm, smoking, bmi, egfr, bptreat, statin, hba1c){
  temp_hba1c <- as.data.frame(t(pred_risk_hba1c_v(sex, age, tc, hdl, sbp, dm, smoking, bmi, egfr, bptreat, statin, hba1c)))
  names(temp_hba1c) <- c("prevent_hba1c_10yr_CVD",
                         "prevent_hba1c_10yr_ASCVD",
                         "prevent_hba1c_10yr_HF",
                         "prevent_hba1c_30yr_CVD",
                         "prevent_hba1c_30yr_ASCVD",
                         "prevent_hba1c_30yr_HF")
  return(temp_hba1c)
}

#' @name pred_risk_sdi
#' @title pred_risk_sdi
#' @param sex Sex, numeric.
#' \itemize{
#'     \item 0 = male
#'     \item 1 = female
#'  }
#' @param age Age (30-79 yrs), numeric.
#' @param tc Total cholesterol (130-320 mg/dL), numeric.
#'
#' \emph{Used in the calculation of non-HDL cholesterol for input into equations, where non-HDL = TC - HDL}.
#' @param hdl High density lipoprotein cholesterol (20-100 mg/dL), numeric.
#' @param sbp Systolic blood pressure (90-200 mmHg), numeric.
#' @param dm Diabetes status (0 or 1), numeric.
#' \itemize{
#'     \item 0 = no history of diabetes
#'     \item 1 = any history of diabetes
#' }
#' @param smoking Smoking status (0 or 1), numeric.
#' \itemize{
#'    \item 0 = non-smoking individual
#'    \item 1 = current smoking
#' }
#' @param bmi Body mass index (18.5-39.9 kg/m^2), numeric.
#' @param egfr Estimated glomerular filtration rate (>0 mL/min/1.73m^2), numeric.
#'
#' \emph{Calculated using the 2021 CKD-EPI creatinine equation (Inker et al., 2021)}.
#' @param bptreat Treatment for hypertension (0 or 1), numeric.
#' \itemize{
#'    \item 0 = no treatment
#'    \item 1 = any treatment
#' }
#' @param statin Statin use (0 or 1), numeric.
#' \itemize{
#'    \item 0 = no statin use
#'    \item 1 = any statin use
#' }
#' @param sdi Social deprivation index decile (integer 1-10), numeric. The original zip
#' code-based SDI must be recoded as a decile for input into these equations. If sdi = NA,
#' missing coefficient will be used for sdi.
#'
#' \emph{From 2015-2019 American Community Survey Data ("Social deprivation index", 2018).}
#'
#' @keywords internal

pred_risk_sdi <- function(sex, age, tc, hdl, sbp, dm, smoking, bmi, egfr, bptreat, statin, sdi) {

  if(!all(is.numeric(sex) & (sex %in% c(0, 1)))) {
    prevent_sdi_30yr_ASCVD = prevent_sdi_30yr_HF = prevent_sdi_30yr_CVD = prevent_sdi_10yr_ASCVD = prevent_sdi_10yr_HF = prevent_sdi_10yr_CVD = NA
  } else {
    if(sex==1) {
      logor_10yr_CVD = -3.461564 +
        0.7754083*((age - 55)/10) +
        0.0221756*((mmol_conversion(tc) - mmol_conversion(hdl)) - 3.5) -
        0.1650828*(mmol_conversion(hdl) - 1.3)/0.3 -
        0.2180808*(min(sbp, 110) - 110)/20 +
        0.3381188*(max(sbp, 110) - 130)/20 +
        0.8624372*(dm) +
        0.4663953*(smoking) +
        0.5919004*(min(egfr, 60) - 60)/(-15) +
        0.0516821*(max(egfr, 60) - 90)/(-15) +
        0.3182166*(bptreat) -
        0.1460816*(statin) -
        0.0574455*(bptreat)*(max(sbp, 110) - 130)/20 +
        0.1302287*(statin)*((mmol_conversion(tc) - mmol_conversion(hdl)) - 3.5) -
        0.083509*(age - 55)/10*((mmol_conversion(tc) - mmol_conversion(hdl)) - 3.5) +
        0.0282181*(age - 55)/10*(mmol_conversion(hdl) - 1.3)/0.3 -
        0.0952647*(age - 55)/10*(max(sbp, 110) - 130)/20 -
        0.2718966*(age - 55)/10*(dm) -
        0.0641738*(age - 55)/10*(smoking) -
        0.1717026*(age - 55)/10*(min(egfr, 60) - 60)/(-15) +
        if(!(is.na(sdi))) {0.1442776*((2 - sdicat(sdi))*(sdicat(sdi))) +
            0.2421409*((sdicat(sdi)-1)*(0.5*sdicat(sdi)))}
      else if (is.na(sdi)) {(0.1885076)}

      logor_10yr_ASCVD = -3.955898 +
        0.7028123*((age - 55)/10) +
        0.1056078*((mmol_conversion(tc) - mmol_conversion(hdl)) - 3.5) -
        0.1502263*(mmol_conversion(hdl) - 1.3)/0.3 -
        0.0488757*(min(sbp, 110) - 110)/20 +
        0.3402681*(max(sbp, 110) - 130)/20 +
        0.838022*(dm) +
        0.4064592*(smoking) +
        0.4838394*(min(egfr, 60) - 60)/(-15) +
        0.0480415*(max(egfr, 60) - 90)/(-15) +
        0.2270648*(bptreat) -
        0.0585626*(statin) -
        0.0349485*(bptreat)*(max(sbp, 110) - 130)/20 +
        0.1017299*(statin)*((mmol_conversion(tc) - mmol_conversion(hdl)) - 3.5) -
        0.062389*(age - 55)/10*((mmol_conversion(tc) - mmol_conversion(hdl)) - 3.5) +
        0.0285106*(age - 55)/10*(mmol_conversion(hdl) - 1.3)/0.3 -
        0.1033711*(age - 55)/10*(max(sbp, 110) - 130)/20 -
        0.2477845*(age - 55)/10*(dm) -
        0.0544326*(age - 55)/10*(smoking) -
        0.1735372*(age - 55)/10*(min(egfr, 60) - 60)/(-15) +
        if(!(is.na(sdi))) {0.1473705*((2 - sdicat(sdi))*(sdicat(sdi))) +
            0.2451878*((sdicat(sdi)-1)*(0.5*sdicat(sdi)))}
      else if (is.na(sdi)) {(0.1691593)}

      logor_10yr_HF = -4.409382 +
        0.8819156*((age - 55)/10) -
        0.4495491*(min(sbp, 110) - 110)/20 +
        0.3457405*(max(sbp, 110) - 130)/20 +
        1.02632*(dm) +
        0.5371646*(smoking) -
        0.0168447*(min(bmi, 30) - 25)/5 +
        0.2805126*(max(bmi, 30) - 30)/5 +
        0.7315223*(min(egfr, 60) - 60)/(-15) +
        0.0651679*(max(egfr, 60) - 90)/(-15) +
        0.3491487*(bptreat) -
        0.0890335*(bptreat)*(max(sbp, 110) - 130)/20 -
        0.0971028*(age - 55)/10*(max(sbp, 110) - 130)/20 -
        0.3528078*(age - 55)/10*(dm) -
        0.106216*(age - 55)/10*(smoking) +
        0.0064998*(age - 55)/10*(max(bmi, 30) - 30)/5 -
        0.1899413*(age - 55)/10*(min(egfr, 60) - 60)/(-15) +
        if(!(is.na(sdi))) {0.1343318*((2 - sdicat(sdi))*(sdicat(sdi))) +
            0.2496522*((sdicat(sdi)-1)*(0.5*sdicat(sdi)))}
      else if (is.na(sdi)) {(0.1915023)}

      logor_30yr_CVD = -1.493211 +
        0.5124233*((age - 55)/10) -
        0.0978159*((age - 55)/10) ^ 2 +
        0.0322131*((mmol_conversion(tc) - mmol_conversion(hdl))- 3.5) -
        0.1717884*(mmol_conversion(hdl)- 1.3)/0.3 -
        0.1364536*(min(sbp, 110) - 110)/20 +
        0.3074443*(max(sbp, 110) - 130)/20 +
        0.6709275*(dm) +
        0.2897728*(smoking) +
        0.1670658*(min(egfr, 60) - 60)/(-15) +
        0.0618439*(max(egfr, 60) - 90)/(-15) +
        0.2969806*(bptreat) -
        0.0665514*(statin) -
        0.0458917*(bptreat)*(max(sbp, 110) - 130)/20 +
        0.1168505*(statin)*((mmol_conversion(tc) - mmol_conversion(hdl))- 3.5) -
        0.0770419*(age - 55)/10*((mmol_conversion(tc) - mmol_conversion(hdl))- 3.5) +
        0.027634*(age - 55)/10*(mmol_conversion(hdl)- 1.3)/0.3 -
        0.0992045*(age - 55)/10*(max(sbp, 110) - 130)/20 -
        0.3208137*(age - 55)/10*(dm) -
        0.134847*(age - 55)/10*(smoking) -
        0.1399842*(age - 55)/10*(min(egfr, 60) - 60)/(-15) +
        if(!(is.na(sdi))) {0.1129725*((2 - sdicat(sdi))*(sdicat(sdi))) +
            0.1975843*((sdicat(sdi)-1)*(0.5*sdicat(sdi)))}
      else if (is.na(sdi)) {(0.1627381)}

      logor_30yr_ASCVD = -2.116951 +
        0.4396545*((age - 55)/10) -
        0.0918489*((age - 55)/10) ^ 2 +
        0.1132729*((mmol_conversion(tc) - mmol_conversion(hdl))- 3.5) -
        0.1544977*(mmol_conversion(hdl)- 1.3)/0.3 +
        0.036315*(min(sbp, 110) - 110)/20 +
        0.3049229*(max(sbp, 110) - 130)/20 +
        0.6344794*(dm) +
        0.234514*(smoking) +
        0.0898312*(min(egfr, 60) - 60)/(-15) +
        0.0564502*(max(egfr, 60) - 90)/(-15) +
        0.1933487*(bptreat) +
        0.0220467*(statin) -
        0.0229229*(bptreat)*(max(sbp, 110) - 130)/20 +
        0.0903326*(statin)*((mmol_conversion(tc) - mmol_conversion(hdl))- 3.5) -
        0.0579383*(age - 55)/10*((mmol_conversion(tc) - mmol_conversion(hdl))- 3.5) +
        0.0274011*(age - 55)/10*(mmol_conversion(hdl)- 1.3)/0.3 -
        0.1039749*(age - 55)/10*(max(sbp, 110) - 130)/20 -
        0.2785102*(age - 55)/10*(dm) -
        0.1167267*(age - 55)/10*(smoking) -
        0.1269382*(age - 55)/10*(min(egfr, 60) - 60)/(-15) +
        if(!(is.na(sdi))) {0.1149139*((2 - sdicat(sdi))*(sdicat(sdi))) +
            0.1976537*((sdicat(sdi)-1)*(0.5*sdicat(sdi)))}
      else if (is.na(sdi)) {(0.1391241)}

      logor_30yr_HF = -2.317899 +
        0.5919097*((age - 55)/10) -
        0.1023133*((age - 55)/10) ^ 2 -
        0.3864727*(min(sbp, 110) - 110)/20 +
        0.301876*(max(sbp, 110) - 130)/20 +
        0.8162909*(dm) +
        0.3449647*(smoking) +
        0.0574975*(min(bmi, 30) - 25)/5 +
        0.2367826*(max(bmi, 30) - 30)/5 +
        0.2790347*(min(egfr, 60) - 60)/(-15) +
        0.0742645*(max(egfr, 60) - 90)/(-15) +
        0.3352935*(bptreat) -
        0.0772532*(bptreat)*(max(sbp, 110) - 130)/20 -
        0.0995144*(age - 55)/10*(max(sbp, 110) - 130)/20 -
        0.4000423*(age - 55)/10*(dm) -
        0.1770335*(age - 55)/10*(smoking) +
        0.0083046*(age - 55)/10*(max(bmi, 30) - 30)/5 -
        0.149585*(age - 55)/10*(min(egfr, 60) - 60)/(-15) +
        if(!(is.na(sdi))) {0.0960646*((2 - sdicat(sdi))*(sdicat(sdi))) +
            0.1987543*((sdicat(sdi)-1)*(0.5*sdicat(sdi)))}
      else if (is.na(sdi)) {(0.1562214)}
    }
    else {
      logor_10yr_CVD =  -3.159572 +
        0.7756377*((age - 55)/10) +
        0.0715325*((mmol_conversion(tc) - mmol_conversion(hdl)) - 3.5) -
        0.0976775*(mmol_conversion(hdl) - 1.3)/0.3 -
        0.5186614*(min(sbp, 110) - 110)/20 +
        0.3235653*(max(sbp, 110) - 130)/20 +
        0.7722496*(dm) +
        0.3761129*(smoking) +
        0.5180893*(min(egfr, 60) - 60)/(-15) +
        0.0118451*(max(egfr, 60) - 90)/(-15) +
        0.2634094*(bptreat) -
        0.1455263*(statin) -
        0.0367013*(bptreat)*(max(sbp, 110) - 130)/20 +
        0.1617785*(statin)*((mmol_conversion(tc) - mmol_conversion(hdl)) - 3.5) -
        0.0507669*(age - 55)/10*((mmol_conversion(tc) - mmol_conversion(hdl)) - 3.5) +
        0.0178356*(age - 55)/10*(mmol_conversion(hdl) - 1.3)/0.3 -
        0.1059337*(age - 55)/10*(max(sbp, 110) - 130)/20 -
        0.2236755*(age - 55)/10*(dm) -
        0.0723216*(age - 55)/10*(smoking) -
        0.1548205*(age - 55)/10*(min(egfr, 60) - 60)/(-15) +
        if(!(is.na(sdi))) {0.0889119*((2 - sdicat(sdi))*(sdicat(sdi))) +
            0.291897*((sdicat(sdi)-1)*(0.5*sdicat(sdi)))}
      else if (is.na(sdi)) {(0.1508151)}

      logor_10yr_ASCVD = -3.624712 +
        0.7150087*((age - 55)/10) +
        0.1627339*((mmol_conversion(tc) - mmol_conversion(hdl)) - 3.5) -
        0.1194988*(mmol_conversion(hdl) - 1.3)/0.3 -
        0.363659*(min(sbp, 110) - 110)/20 +
        0.3179476*(max(sbp, 110) - 130)/20 +
        0.7156422*(dm) +
        0.3404477*(smoking) +
        0.3545754*(min(egfr, 60) - 60)/(-15) +
        0.0157875*(max(egfr, 60) - 90)/(-15) +
        0.1786233*(bptreat) -
        0.1018269*(statin) -
        0.028313*(bptreat)*(max(sbp, 110) - 130)/20 +
        0.1209467*(statin)*((mmol_conversion(tc) - mmol_conversion(hdl)) - 3.5) -
        0.0285806*(age - 55)/10*((mmol_conversion(tc) - mmol_conversion(hdl)) - 3.5) +
        0.0247348*(age - 55)/10*(mmol_conversion(hdl) - 1.3)/0.3 -
        0.0919494*(age - 55)/10*(max(sbp, 110) - 130)/20 -
        0.1981491*(age - 55)/10*(dm) -
        0.0776891*(age - 55)/10*(smoking) -
        0.1284899*(age - 55)/10*(min(egfr, 60) - 60)/(-15) +
        if(!(is.na(sdi))) {0.0728242*((2 - sdicat(sdi))*(sdicat(sdi))) +
            0.2824453*((sdicat(sdi)-1)*(0.5*sdicat(sdi)))}
      else if (is.na(sdi)) {(0.1437348)}

      logor_10yr_HF = -4.058977 +
        0.894179*((age - 55)/10) -
        0.7067398*(min(sbp, 110) - 110)/20 +
        0.350241*(max(sbp, 110) - 130)/20 +
        0.9252453*(dm) +
        0.4364765*(smoking) -
        0.0866297*(min(bmi, 30) - 25)/5 +
        0.3706765*(max(bmi, 30) - 30)/5 +
        0.6696768*(min(egfr, 60) - 60)/(-15) +
        0.0237374*(max(egfr, 60) - 90)/(-15) +
        0.2688352*(bptreat) -
        0.0434892*(bptreat)*(max(sbp, 110) - 130)/20 -
        0.1297155*(age - 55)/10*(max(sbp, 110) - 130)/20 -
        0.299086*(age - 55)/10*(dm) -
        0.1079522*(age - 55)/10*(smoking) +
        0.0130483*(age - 55)/10*(max(bmi, 30) - 30)/5 -
        0.1797791*(age - 55)/10*(min(egfr, 60) - 60)/(-15) +
        if(!(is.na(sdi))) {0.1235632*((2 - sdicat(sdi))*(sdicat(sdi))) +
            0.3592212*((sdicat(sdi)-1)*(0.5*sdicat(sdi)))}
      else if (is.na(sdi)) {(0.17924)}

      logor_30yr_CVD = -1.251031 +
        0.437377*((age - 55)/10) -
        0.104443*((age - 55)/10) ^ 2 +
        0.0812573*((mmol_conversion(tc) - mmol_conversion(hdl))- 3.5) -
        0.1069199*(mmol_conversion(hdl)- 1.3)/0.3 -
        0.2786727*(min(sbp, 110) - 110)/20 +
        0.2729256*(max(sbp, 110) - 130)/20 +
        0.5279006*(dm) +
        0.1878949*(smoking) +
        0.0866569*(min(egfr, 60) - 60)/(-15) +
        0.0594948*(max(egfr, 60) - 90)/(-15) +
        0.2028246*(bptreat) -
        0.0308404*(statin) -
        0.0283679*(bptreat)*(max(sbp, 110) - 130)/20 +
        0.1439353*(statin)*((mmol_conversion(tc) - mmol_conversion(hdl))- 3.5) -
        0.0510854*(age - 55)/10*((mmol_conversion(tc) - mmol_conversion(hdl))- 3.5) +
        0.0150236*(age - 55)/10*(mmol_conversion(hdl)- 1.3)/0.3 -
        0.1095448*(age - 55)/10*(max(sbp, 110) - 130)/20 -
        0.2561109*(age - 55)/10*(dm) -
        0.1282945*(age - 55)/10*(smoking) -
        0.1011023*(age - 55)/10*(min(egfr, 60) - 60)/(-15) +
        if(!(is.na(sdi))) {0.0314626*((2 - sdicat(sdi))*(sdicat(sdi))) +
            0.2003953*((sdicat(sdi)-1)*(0.5*sdicat(sdi)))}
      else if (is.na(sdi)) {(0.0927451)}

      logor_30yr_ASCVD = -1.836632 +
        0.3749788*((age - 55)/10) -
        0.0990063*((age - 55)/10) ^ 2 +
        0.1708505*((mmol_conversion(tc) - mmol_conversion(hdl))- 3.5) -
        0.1272841*(mmol_conversion(hdl)- 1.3)/0.3 -
        0.1275555*(min(sbp, 110) - 110)/20 +
        0.2659339*(max(sbp, 110) - 130)/20 +
        0.4676531*(dm) +
        0.1610104*(smoking) -
        0.0465144*(min(egfr, 60) - 60)/(-15) +
        0.0596996*(max(egfr, 60) - 90)/(-15) +
        0.1147096*(bptreat) +
        0.0052906*(statin) -
        0.0186687*(bptreat)*(max(sbp, 110) - 130)/20 +
        0.1063151*(statin)*((mmol_conversion(tc) - mmol_conversion(hdl))- 3.5) -
        0.0307797*(age - 55)/10*((mmol_conversion(tc) - mmol_conversion(hdl))- 3.5) +
        0.0218126*(age - 55)/10*(mmol_conversion(hdl)- 1.3)/0.3 -
        0.0898242*(age - 55)/10*(max(sbp, 110) - 130)/20 -
        0.210054*(age - 55)/10*(dm) -
        0.1246327*(age - 55)/10*(smoking) -
        0.0629358*(age - 55)/10*(min(egfr, 60) - 60)/(-15) +
        if(!(is.na(sdi))) {0.0199201*((2 - sdicat(sdi))*(sdicat(sdi))) +
            0.194949*((sdicat(sdi)-1)*(0.5*sdicat(sdi)))}
      else if (is.na(sdi)) {(0.0863835)}

      logor_30yr_HF = -2.060187 +
        0.5387527*((age - 55)/10) -
        0.1090333*((age - 55)/10) ^ 2 -
        0.4829094*(min(sbp, 110) - 110)/20 +
        0.2843569*(max(sbp, 110) - 130)/20 +
        0.6827667*(dm) +
        0.2406677*(smoking) +
        0.0618028*(min(bmi, 30) - 25)/5 +
        0.2705615*(max(bmi, 30) - 30)/5 +
        0.2255837*(min(egfr, 60) - 60)/(-15) +
        0.0653632*(max(egfr, 60) - 90)/(-15) +
        0.2263243*(bptreat) -
        0.0316851*(bptreat)*(max(sbp, 110) - 130)/20 -
        0.1258716*(age - 55)/10*(max(sbp, 110) - 130)/20 -
        0.3243709*(age - 55)/10*(dm) -
        0.1596172*(age - 55)/10*(smoking) -
        0.0103092*(age - 55)/10*(max(bmi, 30) - 30)/5 -
        0.1204785*(age - 55)/10*(min(egfr, 60) - 60)/(-15) +
        if(!(is.na(sdi))) {0.0680528*((2 - sdicat(sdi))*(sdicat(sdi))) +
            0.2619865*((sdicat(sdi)-1)*(0.5*sdicat(sdi)))}
      else if (is.na(sdi)) {(0.1151424)}
    }

    prevent_sdi_10yr_CVD = 100*exp(logor_10yr_CVD) / (1 + exp(logor_10yr_CVD))
    prevent_sdi_30yr_CVD = 100*exp(logor_30yr_CVD) / (1 + exp(logor_30yr_CVD))
    prevent_sdi_10yr_ASCVD = 100*exp(logor_10yr_ASCVD) / (1 + exp(logor_10yr_ASCVD))
    prevent_sdi_30yr_ASCVD = 100*exp(logor_30yr_ASCVD) / (1 + exp(logor_30yr_ASCVD))
    prevent_sdi_10yr_HF = 100*exp(logor_10yr_HF) / (1 + exp(logor_10yr_HF))
    prevent_sdi_30yr_HF = 100*exp(logor_30yr_HF) / (1 + exp(logor_30yr_HF))

  }

  if (!is.na(age)) {
    if(age > 59 & age <= 79) {
      prevent_sdi_30yr_ASCVD = prevent_sdi_30yr_HF = prevent_sdi_30yr_CVD = NA
    } else if (age < 30 | age > 79){
      prevent_sdi_30yr_ASCVD = prevent_sdi_30yr_HF = prevent_sdi_30yr_CVD = prevent_sdi_10yr_ASCVD = prevent_sdi_10yr_HF = prevent_sdi_10yr_CVD = NA
    }
  }

  if (is.na(tc) | tc < 130 | tc > 320) { prevent_sdi_30yr_ASCVD = prevent_sdi_30yr_CVD = prevent_sdi_10yr_ASCVD = prevent_sdi_10yr_CVD = NA
  }

  if (is.na(hdl) | hdl < 20 | hdl > 100) { prevent_sdi_30yr_ASCVD = prevent_sdi_30yr_CVD = prevent_sdi_10yr_ASCVD = prevent_sdi_10yr_CVD = NA
  }

  if (is.na(sbp) | sbp < 90 | sbp > 200) { prevent_sdi_30yr_ASCVD = prevent_sdi_30yr_HF = prevent_sdi_30yr_CVD = prevent_sdi_10yr_ASCVD = prevent_sdi_10yr_HF = prevent_sdi_10yr_CVD = NA
  }

  if(!(all(is.numeric(dm)) & (dm %in% c(0, 1)))) { prevent_sdi_30yr_ASCVD = prevent_sdi_30yr_HF = prevent_sdi_30yr_CVD = prevent_sdi_10yr_ASCVD = prevent_sdi_10yr_HF = prevent_sdi_10yr_CVD = NA
  }

  if(!(all(is.numeric(smoking)) & (smoking %in% c(0, 1)))) { prevent_sdi_30yr_ASCVD = prevent_sdi_30yr_HF = prevent_sdi_30yr_CVD = prevent_sdi_10yr_ASCVD = prevent_sdi_10yr_HF = prevent_sdi_10yr_CVD = NA
  }

  if (is.na(egfr) | egfr <= 0) { prevent_sdi_30yr_ASCVD = prevent_sdi_30yr_HF = prevent_sdi_30yr_CVD = prevent_sdi_10yr_ASCVD = prevent_sdi_10yr_HF = prevent_sdi_10yr_CVD = NA
  }

  if(!(all(is.numeric(bptreat)) & (bptreat %in% c(0, 1)))) { prevent_sdi_30yr_ASCVD = prevent_sdi_30yr_HF = prevent_sdi_30yr_CVD = prevent_sdi_10yr_ASCVD = prevent_sdi_10yr_HF = prevent_sdi_10yr_CVD = NA
  }

  if(!(all(is.numeric(statin)) & (statin %in% c(0, 1)))) { prevent_sdi_30yr_ASCVD = prevent_sdi_30yr_CVD = prevent_sdi_10yr_ASCVD = prevent_sdi_10yr_CVD = NA
  }

  if (is.na(bmi) | bmi < 18.5 | bmi >= 40) { prevent_sdi_30yr_HF = prevent_sdi_10yr_HF = NA
  }

  if(!(all(is.numeric(sdi))) & !(all(is.na(sdi)) & (sdi %in% c(NA, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10)))) { prevent_sdi_30yr_ASCVD = prevent_sdi_30yr_HF = prevent_sdi_30yr_CVD = prevent_sdi_10yr_ASCVD = prevent_sdi_10yr_HF = prevent_sdi_10yr_CVD = NA
  }

  prevent_sdi_values <- data.frame(prevent_sdi_10yr_CVD = prevent_sdi_10yr_CVD,
                                   prevent_sdi_10yr_ASCVD = prevent_sdi_10yr_ASCVD,
                                   prevent_sdi_10yr_HF = prevent_sdi_10yr_HF,
                                   prevent_sdi_30yr_CVD = prevent_sdi_30yr_CVD,
                                   prevent_sdi_30yr_ASCVD = prevent_sdi_30yr_ASCVD,
                                   prevent_sdi_30yr_HF = prevent_sdi_30yr_HF)

  return(prevent_sdi_values)
}

#' @name pred_risk_sdi_v
#' @title pred_risk_sdi_v
#' @param sex Sex, numeric.
#' \itemize{
#'     \item 0 = male
#'     \item 1 = female
#'  }
#' @param age Age (30-79 yrs), numeric.
#' @param tc Total cholesterol (130-320 mg/dL), numeric.
#'
#' \emph{Used in the calculation of non-HDL cholesterol for input into equations, where non-HDL = TC - HDL}.
#' @param hdl High density lipoprotein cholesterol (20-100 mg/dL), numeric.
#' @param sbp Systolic blood pressure (90-200 mmHg), numeric.
#' @param dm Diabetes status (0 or 1), numeric.
#' \itemize{
#'     \item 0 = no history of diabetes
#'     \item 1 = any history of diabetes
#' }
#' @param smoking Smoking status (0 or 1), numeric.
#' \itemize{
#'    \item 0 = non-smoking individual
#'    \item 1 = current smoking
#' }
#' @param bmi Body mass index (18.5-39.9 kg/m^2), numeric.
#' @param egfr Estimated glomerular filtration rate (>0 mL/min/1.73m^2), numeric.
#'
#' \emph{Calculated using the 2021 CKD-EPI creatinine equation (Inker et al., 2021)}.
#' @param bptreat Treatment for hypertension (0 or 1), numeric.
#' \itemize{
#'    \item 0 = no treatment
#'    \item 1 = any treatment
#' }
#' @param statin Statin use (0 or 1), numeric.
#' \itemize{
#'    \item 0 = no statin use
#'    \item 1 = any statin use
#' }
#' @param sdi Social deprivation index decile (integer 1-10), numeric. The original
#' zip code-based SDI must be recoded as a decile for input into these equations. If sdi = NA,
#' missing coefficient will be used for sdi.
#'
#' \emph{From 2015-2019 American Community Survey Data ("Social deprivation index", 2018).}
#'
#' @keywords internal

pred_risk_sdi_v <- Vectorize(pred_risk_sdi)

#' @description \strong{prevent_sdi} returns the predicted risks (absolute risk, percent) using
#' the PREVENT base + SDI equation. \cr
#' @details Individuals missing any required input variables (sex, age, sbp, dm, smoking, egfr, bptreat)
#' will return "NA" since these are required variables to calculate risk estimates. Cholesterol variables (tc, hdl, statin)
#' are required for total CVD and ASCVD risk calculations while bmi is required for HF risk
#' calculation; individuals missing these variables will return "NA" only for the calculation of risks
#' requiring the input. For sdi, a missing coefficient is available and may be used when using "prevent_sdi". If risk
#' factor levels are out of range based on how this was defined in the development of the
#' equations (Khan et al., 2024), a risk estimate will not be calculated and the function will return “NA”.
#'
#' @name prevent_sdi
#' @title AHA PREVENT base + SDI equation
#' @param sex Sex, numeric.
#' \itemize{
#'     \item 0 = male
#'     \item 1 = female
#'  }
#' @param age Age (30-79 yrs), numeric.
#' @param tc Total cholesterol (130-320 mg/dL), numeric.
#'
#' \emph{Used in the calculation of non-HDL cholesterol for input into equations, where non-HDL = TC - HDL}.
#' @param hdl High density lipoprotein cholesterol (20-100 mg/dL), numeric.
#' @param sbp Systolic blood pressure (90-200 mmHg), numeric.
#' @param dm Diabetes status (0 or 1), numeric.
#' \itemize{
#'     \item 0 = no history of diabetes
#'     \item 1 = any history of diabetes
#' }
#' @param smoking Smoking status (0 or 1), numeric.
#' \itemize{
#'    \item 0 = non-smoking individual
#'    \item 1 = current smoking
#' }
#' @param bmi Body mass index (18.5-39.9 kg/m^2), numeric.
#' @param egfr Estimated glomerular filtration rate (>0 mL/min/1.73m^2), numeric.
#'
#' \emph{Calculated using the 2021 CKD-EPI creatinine equation (Inker et al., 2021)}.
#' @param bptreat Treatment for hypertension (0 or 1), numeric.
#' \itemize{
#'    \item 0 = no treatment
#'    \item 1 = any treatment
#' }
#' @param statin Statin use (0 or 1), numeric.
#' \itemize{
#'    \item 0 = no statin use
#'    \item 1 = any statin use
#' }
#' @param sdi Social deprivation index decile (integer 1-10), numeric. The original zip
#' code-based SDI must be recoded as a decile for input into these equations. If sdi = NA,
#' missing coefficient will be used for sdi.
#'
#' \emph{From 2015-2019 American Community Survey Data ("Social deprivation index", 2018).}
#'
#' @returns Data frame containing six variables: prevent_sdi_10yr_CVD,
#' prevent_sdi_30yr_CVD, prevent_sdi_10yr_ASCVD,
#' prevent_sdi_30yr_ASCVD, prevent_sdi_10yr_HF, and prevent_sdi_30yr_HF.
#' \itemize{
#'    \item prevent_sdi_10yr_CVD = Predicted 10-year Total CVD risk
#'    \item prevent_sdi_30yr_CVD = Predicted 30-year Total CVD risk
#'    \item prevent_sdi_10yr_ASCVD = Predicted 10-year ASCVD risk
#'    \item prevent_sdi_30yr_ASCVD = Predicted 30-year ASCVD risk
#'    \item prevent_sdi_10yr_HF = Predicted 10-year HF risk
#'    \item prevent_sdi_30yr_HF = Predicted 30-year HF risk
#' }
#'
#' @export
#'
#' @examples
#' ## Calculate predicted risks for a 45-year-old woman with a TC of 200 mg/dL
#' ## and HDL-C of 60 mg/dL (not on statin therapy), a systolic blood pressure of
#' ## 120 mm Hg (not on anti-hypertensive treatment), has diabetes, does not smoke,
#' ## with a BMI of 25 kg/m^2, eGFR of 95 mL/min/1.73m^2, and SDI decile of 9.
#' \donttest{
#'   prevent_sdi(sex = 1, age = 45, tc = 200, hdl = 60, sbp = 120, dm = 1,
#'   smoking = 0, bmi = 25, egfr = 95, bptreat = 0, statin = 0, sdi = 9)
#' }
#' ## Calculate predicted 10-year risks only for 75-year old man
#' ## (no 30-year risks calculated due to age > 75).
#' \donttest{
#'   prevent_sdi(sex = 0, age = 75, tc = 250, hdl = 90, sbp = 130, dm = 0,
#'   smoking = 1, bmi = 30, egfr = 105, bptreat = 0, statin = 1, sdi = 5)
#' }
#' ## Calculate predicted total CVD and ASCVD risks only for 39-year old woman
#' ## (no HF risks calculated due to missing BMI).
#' \donttest{
#'   prevent_sdi(sex = 1, age = 39, tc = 190, hdl = 50, sbp = 110, dm = 0,
#'   smoking = 0, bmi = NA, egfr = 120, bptreat = 0, statin = 0, sdi = 7)
#' }
#' ## Calculate predicted HF risks only for 58-year old man
#' ## (no CVD/ASCVD risks calculated due to missing cholesterol/statin variables).
#' \donttest{
#'   prevent_sdi(sex = 0, age = 58, tc = 230, hdl = NA, sbp = 150, dm = 0,
#'   smoking = 0, bmi = 35, egfr = 45, bptreat = 1, statin = NA, sdi = 2)
#' }
#' ## Calculate predicted risks for an existing data frame called "yourdata" and
#' ## append generated risk scores to original data frame.
#' \donttest{
#'   yourdata <- data.frame(sex = c(1, 0, 1, 0),
#'                        age = c(45, 75, 39, 58),
#'                        tc = c(200, 240, 190, 267),
#'                        hdl = c(60, 90, 50, NA),
#'                        sbp = c(120, 130, 110, 150),
#'                        dm  = c(0, 0, 1, 0),
#'                        smoking = c(1, 0, 0, 0),
#'                        bmi = c(25, 30, NA, 35),
#'                        egfr = c(95, 105, 120, 45),
#'                        bptreat = c(0, 1, 0, 1),
#'                        statin = c(0, 1, 0, NA),
#'                        sdi = c(9, 3, 5, 8))
#'
#'   riskscores <- prevent_sdi(yourdata$sex, yourdata$age, yourdata$tc, yourdata$hdl,
#'                yourdata$sbp, yourdata$dm, yourdata$smoking, yourdata$bmi,
#'                yourdata$egfr, yourdata$bptreat, yourdata$statin,
#'                yourdata$sdi)
#'
#'   yourdata_riskscores <- cbind(yourdata, riskscores)
#'
#'   print(yourdata_riskscores)
#' }
#'

prevent_sdi <- function(sex, age, tc, hdl, sbp, dm, smoking, bmi, egfr, bptreat, statin, sdi){
  temp_sdi <- as.data.frame(t(pred_risk_sdi_v(sex, age, tc, hdl, sbp, dm, smoking, bmi, egfr, bptreat, statin, sdi)))
  names(temp_sdi) <- c("prevent_sdi_10yr_CVD",
                       "prevent_sdi_10yr_ASCVD",
                       "prevent_sdi_10yr_HF",
                       "prevent_sdi_30yr_CVD",
                       "prevent_sdi_30yr_ASCVD",
                       "prevent_sdi_30yr_HF")
  return(temp_sdi)
}
