## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  tidy.opts = list(width.cutoff = 75), 
  tidy = TRUE
)

## ----setup, include = FALSE---------------------------------------------------
library(AHAprevent)

## -----------------------------------------------------------------------------
prevent_base(sex = 1, age = 45, tc = 200, hdl = 60, sbp = 120, dm = 1, smoking = 0, bmi = 25, egfr = 95, bptreat = 0, statin = 0)

## -----------------------------------------------------------------------------
prevent_uacr(sex = 0, age = 75, tc = 240, hdl = 90, sbp = 130, dm = 0, smoking = 0, bmi = 30, egfr= 105, bptreat = 1, statin = 1, uacr = 10)

## -----------------------------------------------------------------------------
prevent_hba1c(sex = 1, age = 39, tc = 190, hdl = 50, sbp = 110, dm = 1, smoking = 0, bmi = NA, egfr = 120, bptreat = 0, statin = 0, hba1c = 8)

## -----------------------------------------------------------------------------
prevent_sdi(sex = 0, age = 58, tc = 267, hdl = NA, sbp = 150, dm = 0, smoking = 0, bmi = 35, egfr = 45, bptreat = 1, statin = NA, sdi = 8)

## -----------------------------------------------------------------------------
## Create data frame
yourdata <- data.frame(sex = c(1, 0, 1, 0),
            age = c(45, 75, 39, 58),
            tc = c(200, 240, 190, 267),
            hdl = c(60, 90, 50, NA),
            sbp = c(120, 130, 110, 150),
            dm  = c(1, 0, 1, 0),
            smoking = c(1, 0, 0, 0),
            bmi = c(25, 30, NA, 35),
            egfr = c(95, 105, 120, 45),
            bptreat = c(0, 1, 0, 1),
            statin = c(0, 1, 0, NA),
            uacr = c(150, 10, 500, 45),
            hba1c = c(8.5, 4, 6, 10.5),
            sdi = c(10, 3, 8, 5))

## Calculate risk scores for data frame    
riskscores <- prevent_full(yourdata$sex, yourdata$age, yourdata$tc, yourdata$hdl,yourdata$sbp, yourdata$dm, yourdata$smoking, yourdata$bmi, yourdata$egfr, yourdata$bptreat, yourdata$statin, yourdata$uacr, yourdata$hba1c, yourdata$sdi)

## Append generated risk scores to original data frame
yourdata_riskscores <- cbind(yourdata, riskscores)

## The final data frame
print(yourdata_riskscores)

